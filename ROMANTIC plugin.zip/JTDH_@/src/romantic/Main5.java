package romantic;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;


import org.apache.commons.io.FileUtils;

import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.metrics.Metrics;
import romantic.parsing.Util;

public class Main5 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, System.out);
		Set<Clazz> cluster = new HashSet<Clazz>();
		for (Clazz c : oosystem.getClazzes()) {
//			if (c.getName().equals("C1") || c.getName().equals("C2") ||	c.getName().equals("C3") || c.getName().equals("C4")) {
			if (c.getName().equals("C1") || c.getName().equals("C2") ||	c.getName().equals("C3")) {
//			if (c.getName().equals("C1") || c.getName().equals("C2")) {
//			if (c.getName().equals("C4")) {

				cluster.add(c);
			}
		}
		System.out.println(cluster);
		System.out.println("coupling" + Metrics.coupling(cluster));
//		System.out.println("tcc" + Metrics.tccClasses(cluster));
		System.out.println("composability" + Metrics.composability(cluster));
		

		
	}

}
