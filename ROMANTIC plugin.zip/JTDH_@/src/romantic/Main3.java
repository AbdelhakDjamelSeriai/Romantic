package romantic;

import java.io.File;
import java.io.IOException;


import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metamodel.OOSystem;
import romantic.parsing.MethodDeclarationVisitor;
import romantic.parsing.MethodInvocationVisitor;
import romantic.parsing.TypeDeclarationVisitor;
import romantic.parsing.Util;


public class Main3 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(Util.readFileAsString("projet/a/C1.java").toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{"projet"}, null, false);
		parser.setUnitName("C1.java");
		parser.setResolveBindings(true);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		//Creation du systeme
		OOSystem oosystem = new OOSystem();
		//Visite de toutes les classes du fichier
		TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
		cu.accept(typeDeclarationVisitor);
		//Pour chaque classe
		for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
			System.out.println("Classe trouvée : " + typeDeclaration.getName().getIdentifier());
			
			Clazz clazz = oosystem.getClazzByName(typeDeclaration.getName().getIdentifier());
			if (clazz==null) {
				clazz = new Clazz(typeDeclaration.getName().getIdentifier());
				oosystem.add(clazz);
			};
			//visite de toutes les declaration de methodes
			MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
			typeDeclaration.accept(methodDeclarationVisitor);
			for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
				System.out.println("Method trouvée : " + methodDeclaration.getName().getIdentifier());
				Method method = new Method(methodDeclaration.getName().getIdentifier(),clazz);
				clazz.addMethod(method);
				//Visite de toutes les invocations de methodes dans chaque declaration de method
				MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
				methodDeclaration.accept(methodInvocationVisitor);
				for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
					//Resoudre le binding pour voir si la classe appartient au systeme
					IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
					if (methodBinding != null) {
						//la classe existe dans le classpath
						String calledClazzName = methodBinding.getDeclaringClass().getName();
						System.out.println("Invocation de methode trouvée : " + calledClazzName + "."+methodInvocation.getName().getIdentifier());
						Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
						Method calledMethod;
						if (calledClazz==null) {
							calledClazz = new Clazz(calledClazzName);
							oosystem.add(calledClazz);
							calledMethod = new Method(methodBinding.getName(),calledClazz);
							calledClazz.addMethod(calledMethod);
						} else {
							// la classe existe dans le systeme
							// donc sa methode existe forcement
							calledMethod = calledClazz.getMethodByName(methodBinding.getName());
						}
						System.out.println("Ajout de " + calledClazzName + "."+calledMethod.getName() + " au invocation de " + method.getName());
						method.addCalledMethod(calledMethod);
					}
				}
			}
			
		}
		System.out.println("*******");
		System.out.println("Système");
		System.out.println("*******");
		for (Clazz clazz : oosystem.getClazzes()) {
			System.out.println(clazz.getName() + "{");
			for (Method method : clazz.getMethods()) {
				System.out.println("  " + method.getName() + "() {");
				for (Method calledMethod : method.getCalledMethods()) {
					System.out.println("    " + calledMethod.getClazz().getName()+"."+calledMethod.getName() + "();");
				}
				System.out.println("  " + "}\n");
			}
			
			System.out.println("}\n");
			
		}
	}
	
	

}
