package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.Random;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import romantic.clustering.ClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;
import romantic.simulatedAnnealing.SimulatedAnnealingUtils;

public class ComponentIdentificationSimulatedAnnealing {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("system.txt")));
		
		Set<Set<Clazz>> solution = SimulatedAnnealingUtils.initialSolution(oosystem.getClazzes());
		double f = SimulatedAnnealingUtils.fSolutionAverage(solution);
		double fBest = f;
		Set<Set<Clazz>> solutionBest = solution;
		int k = 0;
		int kmax = 60;
		double t = 100;
		double lambda = 0.98;
		Random random = new Random();
		while (t>0.09) {
			Set<Set<Clazz>> voisin = SimulatedAnnealingUtils.voisin(solution);
			double fVoisin = SimulatedAnnealingUtils.fSolutionAverage(voisin);
			double diff = fVoisin - f;
			if (fVoisin>fBest) {
				solutionBest = voisin;
				fBest = fVoisin;
			}
			if (fVoisin>f || random.nextDouble() < Math.exp(-(Math.abs(diff))/t)) {
				solution = voisin;
				f = fVoisin;
			}
			t *= lambda;
			k = k + 1;
			System.out.print("f="+SimulatedAnnealingUtils.fSolutionAverage(solution));
			System.out.print(" Math.exp(-(Math.abs(diff))/t)=" + Math.exp(-(Math.abs(diff))/t));
			System.out.print(" T = " + t);
			System.out.println(" diff = " + (diff));
			//System.in.read();
		}
		
		ClusteringUtils.printClusters(solutionBest, new PrintStream(new FileOutputStream("clusters.txt")));

		System.out.println("Qualité de la solution : " + fBest);
		System.out.println("Qualité moyenne de la solution : " + SimulatedAnnealingUtils.fSolutionAverage(solutionBest));
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + solutionBest.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= solutionBest.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : solutionBest) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
	}

}
