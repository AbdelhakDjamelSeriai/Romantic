package romantic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import romantic.clustering.BinaryTree;
import romantic.clustering.ClusteringUtils;
import romantic.clustering.methods.MethodsBinaryTree;
import romantic.clustering.methods.MethodsClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;


public class InterfacesIdentificationMain {
	public static void main(String[] args) throws IOException {
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("system.txt")));
		BinaryTree binaryTree = ClusteringUtils.clustering(oosystem.getClazzes());
		//ClusteringUtils2.parcoursDendro(binaryTree, "  ");
		Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
		ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("clusters.txt")));
		System.out.println("Qualité de la solution : " + GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
//		System.in.read(); // zax
		Set<Clazz> greatestCluster = null;
		int maxClazzPerCluster = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>maxClazzPerCluster) {
				greatestCluster = cluster;
				maxClazzPerCluster = cluster.size();
			}
		}
		
		//Identify Interfaces
		for (Set<Clazz> cluster : clusters) {
			System.out.println("interfaces du cluster " + clusters.size());
			System.out.println("*************************");

			Set<Method> methods = new HashSet<Method>();
			for (Clazz c : cluster) {
				for (Method m : c.getMethods()) {
					System.out.println(m.getClazz().getName()+"."+ m.getName());
					for (Method calledM : m.getCalledMethods()) {
						System.out.println("  " + calledM.getClazz().getName() + "." + calledM.getName());
						if (!cluster.contains(calledM.getClazz())) {
							methods.add(calledM);
						}
					}
				}
			}
			if (methods.size()==0) {
				System.out.println("le nombre de méthodes est zero");
			} else {
				System.out.println("------------------------------------------------");
			MethodsBinaryTree clustering = MethodsClusteringUtils.clustering(methods,clusters);
			Set<Set<Method>> methodsClusters = MethodsClusteringUtils.parcoursDendrogramme(clustering, 0.425,clusters);
			MethodsClusteringUtils.printClusters(methodsClusters, clusters, new PrintStream(new FileOutputStream("cluster"+cluster.size())));
			}
		}
		
//		
	}
}
