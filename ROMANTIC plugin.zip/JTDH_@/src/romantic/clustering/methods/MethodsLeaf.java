package romantic.clustering.methods;

import java.util.HashSet;
import java.util.Set;

import romantic.metamodel.Method;


public class MethodsLeaf extends MethodsNode {
	private Method method;

	public MethodsLeaf() {
		super();
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}

	public MethodsLeaf(Method method) {
		super();
		this.method = method;
	}

	@Override
	public Set<Method> getMethods() {
		Set<Method> methods = new HashSet<Method>();
		methods.add(method);
		return methods;
	}
	
	
}
