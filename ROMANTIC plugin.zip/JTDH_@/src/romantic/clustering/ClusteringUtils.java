package romantic.clustering;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

import romantic.ComponentNaming;
import romantic.metamodel.Clazz;
import romantic.metrics.LexicalCosineSimilarity;
import romantic.metrics.Metrics;

public class ClusteringUtils {
	
	
	public static BinaryTree clustering(Set<Clazz> classes) {
		Set<Node> noeuds = new HashSet<Node>();
		int taille = classes.size();
		double max;
		BinaryTree b = null;
		for (Clazz c : classes) {
			noeuds.add(new Leaf(c));
		}
		for (Node n : noeuds) {
			Set<Clazz> cluster = new HashSet<Clazz>();
			cluster.addAll(n.getClasses());
			max = Metrics.f(cluster);
//			System.out.println(cluster + " " + max); // zax
		}
		do {
			Node[] noeudsArray = noeuds.toArray(new Node[0]);
			int nombre = 1;
			int total = noeuds.size() * (noeuds.size() - 1) / 2;
			Node n1 = noeudsArray[0];
			Node n2 = noeudsArray[1];
			Set<Clazz> cluster = new HashSet<Clazz>();
			cluster.addAll(n1.getClasses());
			cluster.addAll(n2.getClasses());
			max = Metrics.f(cluster);
			//System.out.println(cluster + " " + max);
//			System.out.println( nombre + "/" + total); // zax
			nombre ++;
			for (int i=2;i<noeudsArray.length;i++) {
				Set<Clazz> cluster1 = new HashSet<Clazz>();
				cluster1.addAll(noeudsArray[0].getClasses());
				cluster1.addAll(noeudsArray[i].getClasses());

				double value = Metrics.f(cluster1);
				//System.out.println(cluster1 + " " + value);
//				System.out.println(nombre + "/" + total); // zax
				nombre ++;
				if (value>max) {
					n1 = noeudsArray[0];
					n2 = noeudsArray[i];
					max = value;
				}
			}
			//System.out.println(max);
			for (int i=1;i<noeudsArray.length;i++) {
				for (int j=i+1;j<noeudsArray.length;j++) {
					Set<Clazz> cluster1 = new HashSet<Clazz>();
					cluster1.addAll(noeudsArray[i].getClasses());
					cluster1.addAll(noeudsArray[j].getClasses());

					double value = Metrics.f(cluster1);
					//System.out.println(cluster1 + " " + value);
//					System.out.println(nombre + "/" + total); // zax
					nombre ++;
					if (value>=max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
					}
				}
 			}
			b = new BinaryTree();
			b.setNode1(n1);
			b.setNode2(n2);
//			System.out.println(b.numberOfLeaves()); //zax
//			System.out.println(b.getClasses()); //zax
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
			
		} while (b.numberOfLeaves()!=taille);
		return b;
	}
	
	public static double getSupport(Set<Set<String>> transactions, Set<Clazz> classes){
		int supp = 0;
		Set<String> item = new HashSet<String>();
		for(Clazz c:classes){
			item.add(c.getName());
		}
		ArrayList<Set<String>> t = new ArrayList<Set<String>>(transactions);
		for (int i = 0; i < t.size(); i++) {
			if (t.get(i).containsAll(item)) {
				supp++;
			}
		}
		return (double)supp/transactions.size();
	}
	
	public static BinaryTree clusteringAPI(Set<Clazz> classes, Set<Set<String>> transactions) {
		Set<Node> noeuds = new HashSet<Node>();
		int taille = classes.size();
		double max;
		BinaryTree b = null;
		for (Clazz c : classes) {
			noeuds.add(new Leaf(c));
		}
		for (Node n : noeuds) {
			Set<Clazz> cluster = new HashSet<Clazz>();
			cluster.addAll(n.getClasses());
			max = Metrics.fAPI(cluster);
//			System.out.println(cluster + " " + max); // zax
		}
		do {
			Node[] noeudsArray = noeuds.toArray(new Node[0]);
			int nombre = 1;
			int total = noeuds.size() * (noeuds.size() - 1) / 2;
			Node n1 = noeudsArray[0];
			Node n2 = noeudsArray[1];
			Set<Clazz> cluster = new HashSet<Clazz>();
			cluster.addAll(n1.getClasses());
			cluster.addAll(n2.getClasses());
			max = ( getSupport(transactions, cluster) + Metrics.fAPI(cluster) + LexicalCosineSimilarity.getCosineSimilarity(n1.getClasses(), n2.getClasses())) / 3;
			//System.out.println(cluster + " " + max);
//			System.out.println( nombre + "/" + total); // zax
			nombre ++;
			for (int i=2;i<noeudsArray.length;i++) {
				Set<Clazz> cluster1 = new HashSet<Clazz>();
				cluster1.addAll(noeudsArray[0].getClasses());
				cluster1.addAll(noeudsArray[i].getClasses());

				double value = (getSupport(transactions, cluster) + Metrics.fAPI(cluster1) + LexicalCosineSimilarity.getCosineSimilarity(noeudsArray[0].getClasses(), noeudsArray[i].getClasses())) / 3;
				//System.out.println(cluster1 + " " + value);
//				System.out.println(nombre + "/" + total); // zax
				nombre ++;
				if (value>max) {
					n1 = noeudsArray[0];
					n2 = noeudsArray[i];
					max = value;
				}
			}
			//System.out.println(max);
			for (int i=1;i<noeudsArray.length;i++) {
				for (int j=i+1;j<noeudsArray.length;j++) {
					Set<Clazz> cluster1 = new HashSet<Clazz>();
					cluster1.addAll(noeudsArray[i].getClasses());
					cluster1.addAll(noeudsArray[j].getClasses());

					double value = (getSupport(transactions, cluster) + Metrics.fAPI(cluster1) + LexicalCosineSimilarity.getCosineSimilarity(noeudsArray[i].getClasses(), noeudsArray[j].getClasses())) / 3;
					//System.out.println(cluster1 + " " + value);
//					System.out.println(nombre + "/" + total); // zax
					nombre ++;
					if (value>=max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
					}
				}
 			}
			b = new BinaryTree();
			b.setNode1(n1);
			b.setNode2(n2);
//			System.out.println(b.numberOfLeaves()); //zax
//			System.out.println(b.getClasses()); //zax
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
			
		} while (b.numberOfLeaves()!=taille);
		return b;
	}
	
//	
	public static Set<Set<Clazz>> parcoursDendrogramme(BinaryTree dendrogramme, double t) {
		Set<Set<Clazz>> result = new HashSet<Set<Clazz>>();
		Stack<Node> pile = new Stack<Node>();
		pile.push(dendrogramme);
		while (!pile.isEmpty()) {
			Node pere = pile.pop(); //p�re = perant
			Set<Clazz> pereCluster = pere.getClasses();
			if (pere instanceof BinaryTree) {
				Set<Clazz> fils1Cluster = (((BinaryTree) pere).getNode1().getClasses());
				Set<Clazz> fils2Cluster = (((BinaryTree) pere).getNode2().getClasses());
				double valuePere = Metrics.f(pereCluster);
//				System.out.println("pere : " + valuePere);
//				for (Clazz c : pereCluster) {
//					System.out.println(c);
//				}
				
				double valueFils1 = Metrics.f(fils1Cluster);
				
//				System.out.println("fils1 : " + valueFils1);
//				for (Clazz c : fils1Cluster) {
//					System.out.println(c);
//				}
				
				double valueFils2 = Metrics.f(fils2Cluster);
				
//				System.out.println("fils2 : " + valueFils2);
//				for (Clazz c : fils2Cluster) {
//					System.out.println(c);
//				}
				if (valuePere > (valueFils1 + valueFils2)*t)
//					if (valuePere > (valueFils1*fils1Cluster.size() + valueFils2*fils2Cluster.size())/pereCluster.size()+t)				
//					if (valuePere > valueFils1 && valuePere > valueFils2)
						 {
					result.add(pereCluster);
				} else {
					pile.add(((BinaryTree) pere).getNode1());
					pile.add(((BinaryTree) pere).getNode2());
				}
					
//					if (valueFils1 > valuePere)
//					 {
//						pile.add(((BinaryTree) pere).getNode1());
//			} else if (valueFils2 > valuePere) {
//				pile.add(((BinaryTree) pere).getNode2());
//			} else {
//				result.add(pereComponentShape);
//			}
					
			} else {
				result.add(pereCluster);
			}
		}
		return result;
		
		
	}
	
	public static Set<Set<Clazz>> parcoursDendrogrammeAPI(BinaryTree dendrogramme, double t, Set<Set<String>> transactions) {
		Set<Set<Clazz>> result = new HashSet<Set<Clazz>>();
		Stack<Node> pile = new Stack<Node>();
		pile.push(dendrogramme);
		while (!pile.isEmpty()) {
			Node pere = pile.pop(); //p�re = perant
			Set<Clazz> pereCluster = pere.getClasses();
			if (pere instanceof BinaryTree) {
				Set<Clazz> fils1Cluster = (((BinaryTree) pere).getNode1().getClasses());
				Set<Clazz> fils2Cluster = (((BinaryTree) pere).getNode2().getClasses());
				double valuePere = (getSupport(transactions, pereCluster)+Metrics.fAPI(pereCluster))/2;
//				System.out.println("pere : " + valuePere);
//				for (Clazz c : pereCluster) {
//					System.out.println(c);
//				}
				
				double valueFils1 = (getSupport(transactions, fils1Cluster)+Metrics.fAPI(fils1Cluster))/2;
				
//				System.out.println("fils1 : " + valueFils1);
//				for (Clazz c : fils1Cluster) {
//					System.out.println(c);
//				}
				
				double valueFils2 = (getSupport(transactions, fils2Cluster)+Metrics.fAPI(fils2Cluster))/2;
				
//				System.out.println("fils2 : " + valueFils2);
//				for (Clazz c : fils2Cluster) {
//					System.out.println(c);
//				}
				if (valuePere > (valueFils1 + valueFils2)*t)
//					if (valuePere > (valueFils1*fils1Cluster.size() + valueFils2*fils2Cluster.size())/pereCluster.size()+t)				
//					if (valuePere > valueFils1 && valuePere > valueFils2)
						 {
					result.add(pereCluster);
				} else {
					pile.add(((BinaryTree) pere).getNode1());
					pile.add(((BinaryTree) pere).getNode2());
				}
					
//					if (valueFils1 > valuePere)
//					 {
//						pile.add(((BinaryTree) pere).getNode1());
//			} else if (valueFils2 > valuePere) {
//				pile.add(((BinaryTree) pere).getNode2());
//			} else {
//				result.add(pereComponentShape);
//			}
					
			} else {
				result.add(pereCluster);
			}
		}
		return result;
		
		
	}
	
	public static void parcoursDendro(BinaryTree dendro, String s) {
		System.out.println(s+ "pere" + dendro.getClasses());
		if (dendro.getNode1() instanceof BinaryTree)
		parcoursDendro((BinaryTree)dendro.getNode1(),s+"  ");
		else
			System.out.println(s + "  fils1" + ((Leaf)dendro.getNode1()).getClasses());
		if (dendro.getNode2() instanceof BinaryTree)
		parcoursDendro((BinaryTree)dendro.getNode2(),s+"  ");
		else
			System.out.println(s + "  fils2" + ((Leaf)dendro.getNode2()).getClasses());
	}
	
	
//	public static ComponentShape createComponentShapeFromClasses(Set<Class> classes) {
//		ConfigurationShape configurationShape = new ConfigurationShape();
//		ComponentShape componentShape = new ComponentShape();
//		componentShape.getClasses().addAll(classes);
//		componentShape.setConfigurationShape(configurationShape);
//		configurationShape.getComponentShapes().add(componentShape);
//		return componentShape;
//	}
//	
//	public static Set<ComponentShape> clusteringBasic(List<Class> classes, double t) {
//		Set<ComponentShape> partition = new HashSet<ComponentShape>();
//		while (!classes.isEmpty()) {
//			Class ci = classes.get(0);
//			ComponentShape c = new ComponentShape();
//			c.getClasses().add(ci);
//			classes.remove(ci);
//			List<Class> classesClone = new ArrayList<Class>();
//			for (Class cj : classes) {
//				classesClone.add(cj);
//			}
//			for (Class cj : classesClone) {
//				System.out.println(ci + "," + cj + ":" +ObjectiveFunctionUtils.objFunction(ci, cj));
//				if (ObjectiveFunctionUtils.objFunction(ci, cj)>=t) {
//					c.getClasses().add(cj);
//					classes.remove(cj);
//				}
//			}
//			partition.add(c);
//			System.err.println("classes restantes : " + classes.size());
//		}
//		return partition;
//	}
	
	public static void printClusters(Set<Set<Clazz>> clusters, PrintStream out) {

		out.println("Number of clusters : " + clusters.size());

		out.println();
		int i = 1;
		for (Set<Clazz> cluster: clusters) {
			out.println("Cluster " + i + "(" + cluster.size()+" classes) " + "specificity : " + Metrics.specificity(cluster)+" composability : " + Metrics.composability(cluster) + " autonomy : " + Metrics.autonomy(cluster));
			out.println("Component Name : " + ComponentNaming.componentName(cluster));
			for (Clazz clazz: cluster) {
				out.println("  " + clazz.getName());
			}
			i++;
			out.println();
		}
	}

}
