package romantic.clustering;

import java.util.HashSet;
import java.util.Set;

import romantic.metamodel.Clazz;


public class Leaf extends Node {
	private Clazz clazz;

	public Leaf() {
		super();
	}

	public Clazz getClazz() {
		return clazz;
	}

	public void setClazz(Clazz clazz) {
		this.clazz = clazz;
	}

	public Leaf(Clazz clazz) {
		super();
		this.clazz = clazz;
	}

	@Override
	public Set<Clazz> getClasses() {
		Set<Clazz> classes = new HashSet<Clazz>();
		classes.add(clazz);
		return classes;
	}
	
	
}
