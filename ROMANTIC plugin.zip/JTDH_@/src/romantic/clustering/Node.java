package romantic.clustering;

import java.util.Set;

import romantic.metamodel.Clazz;


public abstract class Node {
	public abstract Set<Clazz> getClasses();
}
