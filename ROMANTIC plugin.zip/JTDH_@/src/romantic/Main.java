package romantic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;

public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(readFileAsString("C:\\Users\\zakarea.alshara\\Desktop\\Mobile Media\\p01").toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{"projet"}, null, true);
		parser.setUnitName("C1.java");
		parser.setResolveBindings(true);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		
		cu.accept(new ASTVisitor() {
 			public boolean visit(MethodDeclaration node) {
				System.out.println("Declaration " + node.getName().getIdentifier());
				return true;
			}
 
			public boolean visit(MethodInvocation methodInvocation) {
				System.out.println("Invocation " + methodInvocation.getName().getIdentifier());
				System.out.println(methodInvocation.resolveMethodBinding().getDeclaringClass().getName());
				return true;
			}
 
		});
	}
	
	private static String readFileAsString(String filePath)
		    throws java.io.IOException{
		        StringBuffer fileData = new StringBuffer(1000);
		        BufferedReader reader = new BufferedReader(new FileReader(filePath));
		        char[] buf = new char[1024];
		        int numRead=0;
		        while((numRead=reader.read(buf)) != -1){
		            String readData = String.valueOf(buf, 0, numRead);
		            fileData.append(readData);
		            buf = new char[1024];
		        }
		        reader.close();
		        return fileData.toString();
		    }

}
