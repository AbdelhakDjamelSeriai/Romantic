package romantic.parsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.Flags;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import romantic.metamodel.Attribute;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metamodel.OOSystem;

public class Util {
	public static String readFileAsString(String filePath)
		    throws java.io.IOException{
		        StringBuffer fileData = new StringBuffer(1000);
		        BufferedReader reader = new BufferedReader(new FileReader(filePath));
		        char[] buf = new char[1024];
		        int numRead=0;
		        while((numRead=reader.read(buf)) != -1){
		            String readData = String.valueOf(buf, 0, numRead);
		            fileData.append(readData);
		            buf = new char[1024];
		        }
		        reader.close();
		        return fileData.toString();
		    }
	
	public static void extractClass(String filePath,OOSystem oosystem) {
		
	}
	
	public static void parse3(String filename, OOSystem oosystem) throws IOException {
		ASTParser parser = ASTParser.newParser(AST.JLS4); // zax change from AST.JLS3 to AST.JLS4
		parser.setSource(Util.readFileAsString("projet/"+filename).toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{"projet"}, null, true);
		parser.setUnitName(new File(filename).getName());
		parser.setResolveBindings(true);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		//Creation du systeme
		//OOSystem oosystem = new OOSystem();
		//Visite de toutes les classes du fichier
		TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
		cu.accept(typeDeclarationVisitor);
		//Pour chaque classe
		for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
			System.out.println("Classe trouvée : " + typeDeclaration.getName().getIdentifier());
			Clazz clazz = oosystem.getClazzByName(typeDeclaration.getName().getIdentifier());
			if (clazz==null) {
				clazz = new Clazz(typeDeclaration.getName().getIdentifier());
				oosystem.add(clazz);
			};
			//visite de toutes les declaration de methodes
			MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
			typeDeclaration.accept(methodDeclarationVisitor);
			for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
				System.out.println("Method trouvée : " + methodDeclaration.getName().getIdentifier());
				Method method = clazz.getMethodByName(methodDeclaration.getName().getIdentifier());
				if (method==null) {
					method = new Method(methodDeclaration.getName().getIdentifier(),clazz);
					clazz.addMethod(method);
				}
				//Visite de toutes les invocations de methodes dans chaque declaration de method
				MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
				methodDeclaration.accept(methodInvocationVisitor);
				for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
					//Resoudre le binding pour voir si la classe appartient au systeme
					IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
					if (methodBinding != null) {
						//la classe existe dans le classpath
						String calledClazzName = methodBinding.getDeclaringClass().getName();
						//code ajouteé
						String s = methodBinding.getDeclaringClass().getQualifiedName();
						s = s.replace('.', '/');
						s = "projet/".concat(s.concat(".java"));
						if (new File(s).exists()) {
							System.err.println("exist " + s);
							System.out.println("Invocation de methode trouvée : " + calledClazzName + "."+methodInvocation.getName().getIdentifier());
							Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
							Method calledMethod;
							if (calledClazz==null) {
								calledClazz = new Clazz(calledClazzName);
								oosystem.add(calledClazz);
								calledMethod = new Method(methodBinding.getName(),calledClazz);
								calledClazz.addMethod(calledMethod);
							} else {
								// la classe existe dans le systeme
								calledMethod = calledClazz.getMethodByName(methodBinding.getName());
								if (calledMethod==null) {
									calledMethod = new Method(methodBinding.getName(),calledClazz);
									calledClazz.addMethod(calledMethod);
								}
							}
							System.out.println("Ajout de " + calledClazzName + "."+calledMethod.getName() + " au invocation de " + method.getName());
							method.addCalledMethod(calledMethod);
						}
						else 
							System.err.println("not exist " + s);
						//fin code ajouté

					}
				}
				
				//Visite de tous les acces aux attributs dans chaque declaration de méthode
				AttributeAccessVisitor attributeAccessVisitor = new AttributeAccessVisitor();
				methodDeclaration.accept(attributeAccessVisitor);
				for (SimpleName simpleName : attributeAccessVisitor.getFields()) {
					//Resoudre le binding pour voir si l'instruction est un access à une variable
					IVariableBinding variableBinding = (IVariableBinding)simpleName.resolveBinding();
					if (variableBinding != null) {
						//la classe existe dans le classpath
						//si getDeclaringClass retourne null alors c'est une variable local
						if (variableBinding.getDeclaringClass()!=null) {
							String calledClazzName = variableBinding.getDeclaringClass().getName();
							//code ajouteé
							String s = variableBinding.getDeclaringClass().getQualifiedName();
							s = s.replace('.', '/');
							s = "projet/".concat(s.concat(".java"));
							if (new File(s).exists()) {
								System.err.println("exist "+s);
								System.out.println("Accés à attribut trouvée : " + calledClazzName + "."+variableBinding.getName());
								Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
								Attribute accessedAttribute;
								if (calledClazz==null) {
									calledClazz = new Clazz(calledClazzName);
									oosystem.add(calledClazz);
									accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
									calledClazz.addAttribute(accessedAttribute);
								} else {
									// la classe existe dans le systeme
									accessedAttribute = calledClazz.getAttributeByName(variableBinding.getName());
									if (accessedAttribute==null) {
										accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
										calledClazz.addAttribute(accessedAttribute);
								}
							}
							System.out.println("Ajout de " + calledClazzName + "."+accessedAttribute.getName() + " au acces de " + method.getName());
							method.addAccessedAttribute(accessedAttribute);
							} else {
								System.err.println("not exist "+s);
							}
						}
					}
				}
				
			}
			
		}
	}
	
	public static void parse(String filename, OOSystem oosystem) throws IOException {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
		parser.setSource(Util.readFileAsString(filename).toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{"D:/Study/EclipseWarkSpace/test"}, null, false); //zax change it from true to false >> public void setEnvironment(String[] classpathEntries,String[] sourcepathEntries,String[] encodings,boolean includeRunningVMBootclasspath)
		parser.setUnitName(new File(filename).getName());// zax todo (check if it change the results !!!): from Name() to getCanonicalPath()
		parser.setResolveBindings(true);
		parser.setBindingsRecovery(true);//zax : added by zax
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		
		//Creation du systeme
		//OOSystem oosystem = new OOSystem();
		//Visite de toutes les classes du fichier
		TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
		cu.accept(typeDeclarationVisitor);
		//Pour chaque classe
		//zax hint : typeDeclaration = source code + hint in class >> have a source code for a class
		for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
			System.out.println("Type Declaration : " + typeDeclaration.resolveBinding().getQualifiedName());//zax  : from getIdentifier to getFullyQualifiedName()
			Clazz clazz = oosystem.getClazzByName(typeDeclaration.resolveBinding().getQualifiedName());//zax  : from getIdentifier to getFullyQualifiedName()
			if (clazz==null) {
				clazz = new Clazz(typeDeclaration.resolveBinding().getQualifiedName());//zax  : from getIdentifier to resolveBinding().getQualifiedName()
				oosystem.add(clazz);
			}
			//visite de toutes les declaration de methodes
			MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
			typeDeclaration.accept(methodDeclarationVisitor);
			//zax hint : methodDeclaration = source code + hint in method >> have a source code for a method
			for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
				
				String methodDeclarationName = "";
				boolean isPublic = false;
				if(typeDeclaration.resolveBinding().getName() != null)
					methodDeclarationName = methodDeclaration.getName().getFullyQualifiedName();
				
				if(Flags.isPublic(methodDeclaration.getModifiers()))
					isPublic = true;
				
				System.out.println("Method Declaration : " + methodDeclarationName);//zax  : from getIdentifier to .resolveBinding().getDeclaringClass().getPackage().getName()+"."+methodDeclaration.resolveBinding().getDeclaringClass().getName()
				Method method = clazz.getMethodByName(methodDeclarationName);//zax  : from getIdentifier to getFullyQualifiedName()
				
				if (method==null) {
					method = new Method(methodDeclarationName,clazz);//zax  : from getIdentifier to getFullyQualifiedName()
					method.setPublicFlag(isPublic);
					clazz.addMethod(method);
				}
				
				
				//Visite de toutes les invocations de methodes dans chaque declaration de method
				//zax hint : Visit all invocations of methods in each declaration of method
				
				MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
				methodDeclaration.accept(methodInvocationVisitor);
				
				for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
					
//					SuperMethodInvocation
					//Resoudre le binding pour voir si la classe appartient au systeme
					//zax hint : Solve the binding to see if the class belongs to the system

					IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
//					IMethodBinding methodBinding = (IMethodBinding) methodInvocation.getName().resolveBinding();
					
					
//					if (methodBinding != null && methodBinding.getDeclaringClass() != null) { //zax :  && methodBinding.getDeclaringClass() != null
						//la classe existe dans le classpath
//						String methodBindingPackage = "";
						String calledClassName = "";
//						if(methodInvocation.getClass().getPackage().getName() != null)
//							methodBindingPackage = methodInvocation.getClass().getPackage().getName();
						if(methodBinding != null){
							calledClassName = methodBinding.getDeclaringClass().getQualifiedName()+ "." ;
						}
						String calledMethodName = calledClassName + methodInvocation.getName();
						System.out.println("Method Invocation : " + calledMethodName);//zax  : from getIdentifier to getFullyQualifiedName()
						Clazz calledClazz = oosystem.getClazzByName(calledClassName);
						Method calledMethod;
						
//						if(Flags.isPublic(methodInvocation.getModifiers()))
//							isPublic = true;
						
						if (calledClazz==null) {
							calledClazz = new Clazz(calledClassName);
							oosystem.add(calledClazz);
							calledMethod = new Method(calledMethodName, calledClazz);
//							calledMethod.setPublicFlag(isPublic);
							calledClazz.addMethod(calledMethod);
						} else {
							// la classe existe dans le systeme
							calledMethod = calledClazz.getMethodByName(calledMethodName);
							if (calledMethod==null) {
								calledMethod = new Method(calledMethodName, calledClazz);
//								calledMethod.setPublicFlag(isPublic);
								calledClazz.addMethod(calledMethod);
							}
						}
						System.out.println("Adding " + calledMethodName + " the invocation " + method.getName());
						method.addCalledMethod(calledMethod);
//					}
				}
				
				//Visite de tous les acces aux attributs dans chaque declaration de méthode
				//zax hint : Visit all access to the attributes of each method declaration
				AttributeAccessVisitor attributeAccessVisitor = new AttributeAccessVisitor();
				methodDeclaration.accept(attributeAccessVisitor);
				for (SimpleName simpleName : attributeAccessVisitor.getFields()) {
					//Resoudre le binding pour voir si l'instruction est un access à une variable
					IVariableBinding variableBinding = (IVariableBinding)simpleName.resolveBinding();
					if (variableBinding != null) {
						//la classe existe dans le classpath
						//si getDeclaringClass retourne null alors c'est une variable local
						if (variableBinding.getDeclaringClass()!=null) {
							String variableBindingPackage = "";
							String variableBindingName = "";
							if(variableBinding.getDeclaringClass().getPackage().getName() != null)
								variableBindingPackage = variableBinding.getDeclaringClass().getPackage().getName();
							if(variableBinding.getDeclaringClass().getName() != null)
								variableBindingName = variableBinding.getDeclaringClass().getName();
							
							String calledClazzName = variableBindingPackage + "." + variableBindingName;
							System.out.println("Variable Binding : " + calledClazzName + "."+variableBinding.getName());
							Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
							Attribute accessedAttribute;
							if (calledClazz==null) {
								calledClazz = new Clazz(calledClazzName);
								oosystem.add(calledClazz);
								accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
							} else {
								// la classe existe dans le systeme
								accessedAttribute = calledClazz.getAttributeByName(variableBinding.getName());
								if (accessedAttribute==null) {
									accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
								}
							}
							System.out.println("Adding " + calledClazzName + "."+accessedAttribute.getName() + " the access of " + method.getName());
							method.addAccessedAttribute(accessedAttribute);
						}
					}
				}
				
			}
			
		}
	}
	
	
	public static void parse2(String filename, OOSystem oosystem) throws IOException {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
		parser.setSource(Util.readFileAsString("projet/"+filename).toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{"projet"}, null, true);
		parser.setUnitName(new File(filename).getName());
		parser.setResolveBindings(true);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		//Creation du systeme
		//OOSystem oosystem = new OOSystem();
		//Visite de toutes les classes du fichier
		TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
		cu.accept(typeDeclarationVisitor);
		//Pour chaque classe
		
		//Classes déclarés
		Set<String> declaredClasses = new HashSet<String>();
		for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
			System.out.println("Classe trouvée : " + typeDeclaration.getName().getIdentifier());
			Clazz clazz = oosystem.getClazzByName(typeDeclaration.getName().getIdentifier());
			declaredClasses.add(typeDeclaration.getName().toString());
			if (clazz==null) {
				clazz = new Clazz(typeDeclaration.getName().getIdentifier());
				oosystem.add(clazz);
			};
			//visite de toutes les declaration de methodes
			MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
			typeDeclaration.accept(methodDeclarationVisitor);
			for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
				System.out.println("Method trouvée : " + methodDeclaration.getName().getIdentifier());
				Method method = clazz.getMethodByName(methodDeclaration.getName().getIdentifier());
				if (method==null) {
					method = new Method(methodDeclaration.getName().getIdentifier(),clazz);
					clazz.addMethod(method);
				}
				//Visite de toutes les invocations de methodes dans chaque declaration de method
				MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
				methodDeclaration.accept(methodInvocationVisitor);
				for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
					//Resoudre le binding pour voir si la classe appartient au systeme
					IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
					if (methodBinding != null) {
						//la classe existe dans le classpath
						String calledClazzName = methodBinding.getDeclaringClass().getName();
						System.out.println("Invocation de methode trouvée : " + calledClazzName + "."+methodInvocation.getName().getIdentifier());
						Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
						Method calledMethod;
						if (calledClazz==null) {
							calledClazz = new Clazz(calledClazzName);
							oosystem.add(calledClazz);
							calledMethod = new Method(methodBinding.getName(),calledClazz);
							calledClazz.addMethod(calledMethod);
						} else {
							// la classe existe dans le systeme
							calledMethod = calledClazz.getMethodByName(methodBinding.getName());
							if (calledMethod==null) {
								calledMethod = new Method(methodBinding.getName(),calledClazz);
								calledClazz.addMethod(calledMethod);
							}
						}
						System.out.println("Ajout de " + calledClazzName + "."+calledMethod.getName() + " au invocation de " + method.getName());
						method.addCalledMethod(calledMethod);
					}
				}
				
				//Visite de tous les acces aux attributs dans chaque declaration de méthode
				AttributeAccessVisitor attributeAccessVisitor = new AttributeAccessVisitor();
				methodDeclaration.accept(attributeAccessVisitor);
				for (SimpleName simpleName : attributeAccessVisitor.getFields()) {
					//Resoudre le binding pour voir si l'instruction est un access à une variable
					IVariableBinding variableBinding = (IVariableBinding)simpleName.resolveBinding();
					if (variableBinding != null) {
						//la classe existe dans le classpath
						//si getDeclaringClass retourne null alors c'est une variable local
						if (variableBinding.getDeclaringClass()!=null) {
							String calledClazzName = variableBinding.getDeclaringClass().getName();
							System.out.println("Accés à attribut trouvée : " + calledClazzName + "."+variableBinding.getName());
							Clazz calledClazz = oosystem.getClazzByName(calledClazzName);
							Attribute accessedAttribute;
							if (calledClazz==null) {
								calledClazz = new Clazz(calledClazzName);
								oosystem.add(calledClazz);
								accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
							} else {
								// la classe existe dans le systeme
								accessedAttribute = calledClazz.getAttributeByName(variableBinding.getName());
								if (accessedAttribute==null) {
									accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
								}
							}
							System.out.println("Ajout de " + calledClazzName + "."+accessedAttribute.getName() + " au acces de " + method.getName());
							method.addAccessedAttribute(accessedAttribute);
						}
					}
				}
				
			}
			
		}
	}
	
	
	
	
	public static void printSystem(OOSystem oosystem, PrintStream out) {
		out.println("*******");
		out.println("Système");
		out.println("*******");
		out.println(oosystem.getClazzes().size() + " classes");
		for (Clazz clazz : oosystem.getClazzes()) {
			out.println(clazz.getName() + "{");
			for (Method method : clazz.getMethods()) {
				out.println("  " + method.getName() + "() {");
				for (Method calledMethod : method.getCalledMethods()) {
					out.println("    " + calledMethod.getClazz().getName()+"."+calledMethod.getName() + "();");
				}
				for (Attribute accessedAttribute : method.getAccessedAttributes(oosystem.getClazzes())) {
					out.println("    " + accessedAttribute.getClazz().getName()+"."+accessedAttribute.getName()+";");
				}
				out.println("  " + "}\n");
			}
			
			for (Attribute attribute : clazz.getAttributes()) {
				out.println("  " + attribute.getName() + ";");
			}
			
			out.println("}\n");
			
		}
	}
}
