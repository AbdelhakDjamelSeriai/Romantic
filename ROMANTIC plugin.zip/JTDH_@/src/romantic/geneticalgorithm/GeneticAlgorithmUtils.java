package romantic.geneticalgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import romantic.metamodel.Clazz;
import romantic.metrics.Metrics;

public class GeneticAlgorithmUtils {
//	public static Set<Set<Set<Clazz>>> initialPopulation(Set<Clazz> clazzes, int numberOfChromosomes) {
//		Set<Set<Set<Clazz>>> population = new HashSet<Set<Set<Clazz>>>();
//		Random random = new Random();
//		while (population.size()!=numberOfChromosomes) {
//			List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>();
//			//générer un chromosome aléatoirement
//			int nombreDeGenes = random.nextInt(clazzes.size())/2 + 1;
//			for (int j=0;j<nombreDeGenes;j++) {
//				Set<Clazz> cluster = new HashSet<Clazz>();
//				chromosomeAsList.add(cluster);
//			}
//			for (Clazz clazz : clazzes) {
//				int k = random.nextInt(nombreDeGenes);
//				chromosomeAsList.get(k).add(clazz);
//			}
//		
//			Set<Set<Clazz>> genesToRemove = new HashSet<Set<Clazz>>();
//			for (Set<Clazz> cluster : chromosomeAsList) {
//				if (cluster.size()==0) {
//					genesToRemove.add(cluster);
//				}
//			}
//			chromosomeAsList.removeAll(genesToRemove);
//			Set<Set<Clazz>> chromosome = new HashSet<Set<Clazz>>(chromosomeAsList);
//			population.add(chromosome);
//		}
//		return population;
//	}
//	
//	public static Set<Set<Set<Clazz>>> selection1(Set<Set<Set<Clazz>>> populationInitiale) {
//		//TODO première selection
//		Set<Set<Set<Clazz>>> population = new HashSet<Set<Set<Clazz>>>();
//		int nombreDeChromosomes = populationInitiale.size() * 3 / 4;
//		Random random = new Random();
//		while (population.size()!=nombreDeChromosomes) {
//			for (Set<Set<Clazz>> chromosome : populationInitiale) {
//				double r = random.nextDouble();
//				if (r<=fChromosomeComposant(chromosome)) {
//					population.add(chromosome);
//					if (population.size()==nombreDeChromosomes) {
//						break;
//					}
//				}
//			}
//		}
//		return population;
//	}
//	
//	public static void mutation(Set<Set<Clazz>> chromosome, double probability) {
//		Random random = new Random();
//		double r = random.nextDouble();
//		if (r<probability) {
//			double rFusion = random.nextDouble();
//			if (rFusion<probability/3) {
//				List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
//				int index1 = random.nextInt(chromosomeAsList.size());
//				Set<Clazz> gene1 = chromosomeAsList.get(index1);
//				int index2 = index1;
//				while (index2==index1) {
//					index2 = random.nextInt(chromosomeAsList.size());
//				}
//				Set<Clazz> gene2 = chromosomeAsList.get(index2);
//				Set<Clazz> fusion = new HashSet<Clazz>(gene1);
//				fusion.addAll(gene2);
//				chromosome.remove(gene1);
//				chromosome.remove(gene2);
//				chromosome.add(fusion);
//			}
//			double rSeparation = random.nextDouble();
//			if (rSeparation<probability/3) {
//				List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
//				int index = random.nextInt(chromosomeAsList.size());
//				Set<Clazz> geneToSeparate = chromosomeAsList.get(index);
//				List<Clazz> geneToSeparateAsList = new ArrayList<Clazz>(geneToSeparate);
//				int index2 = random.nextInt(geneToSeparate.size());
//				List<Clazz> gene1AsList = geneToSeparateAsList.subList(0, index2);
//				List<Clazz> gene2AsList = geneToSeparateAsList.subList(index2, geneToSeparate.size());
//				Set<Clazz> gene1 = new HashSet<Clazz>(gene1AsList);
//				Set<Clazz> gene2 = new HashSet<Clazz>(gene2AsList);
//				chromosome.remove(geneToSeparate);
//				if (gene1.size()>0)
//					chromosome.add(gene1);
//				if (gene2.size()>0)
//				chromosome.add(gene2);
//				
//			}
//			double rAdaptation = random.nextDouble();
//			if (rAdaptation<probability/3) {
//				//adaptation
//			}
//			
//		}
//		
//	}
//	
//	public static void mutationPopulation(Set<Set<Set<Clazz>>> population,double probability) {
//		for (Set<Set<Clazz>> chromosome : population) {
//			mutation(chromosome,probability);
//		}
//	}
//	
//	public static void croisementChromosomes(Set<Set<Clazz>> chromosome1, Set<Set<Clazz>> chromosome2, Set<Set<Set<Clazz>>> population) {
//		//TODO croisement de deux chromosomes
//		//TODO insertion des deux enfants dans la population
//		Random random = new Random();
//		Set<Set<Clazz>> enfant = new HashSet<Set<Clazz>>();
//		for (Set<Clazz> gene : chromosome1) {
//			Set<Clazz> geneEnfant = new HashSet<Clazz>();
//			geneEnfant.addAll(gene);
//			enfant.add(geneEnfant);
//		}
//		List<Set<Clazz>> chromosome2AsArrayList = new ArrayList<Set<Clazz>>(chromosome2);
//		Set<Clazz> gene2 = chromosome2AsArrayList.get(random.nextInt(chromosome2.size()));
//		for (Clazz clazz : gene2) {
//			for (Set<Clazz> geneEnfant : enfant) {
//				if (geneEnfant.contains(clazz)) {
//					geneEnfant.remove(clazz);
//				}
//			}
//		}
//		enfant.add(gene2);
//
//		Set<Set<Clazz>> enfantPropre = new HashSet<Set<Clazz>>();
//		for (Set<Clazz> gene : enfant) {
//			if (gene.size()>0) {
//				enfantPropre.add(gene);
//			}
//		}
//		
//		population.add(enfantPropre);
//	}
//	
//	public static void croisement(Set<Set<Set<Clazz>>> population) {
//		List<Set<Set<Clazz>>> populationAsArrayList = new ArrayList<Set<Set<Clazz>>>(population);
//		for (int i=0;i<populationAsArrayList.size();i++)
//			for (int j=i+1;j<populationAsArrayList.size();j++) {
//				croisementChromosomes(populationAsArrayList.get(i), populationAsArrayList.get(j), population);
//				croisementChromosomes(populationAsArrayList.get(j), populationAsArrayList.get(i), population);
//			}
//	}
//	
//	public static Set<Set<Set<Clazz>>> selection2(Set<Set<Set<Clazz>>> population, int n) {
//		//TODO 2eme selection qui selection les n individus les plus adaptés
//		List<Set<Set<Clazz>>> populationAsList = new ArrayList<Set<Set<Clazz>>>(population);
//		Collections.sort(populationAsList, new Comparator<Set<Set<Clazz>>>() {
//			@Override
//			public int compare(Set<Set<Clazz>> chromosome1, Set<Set<Clazz>> chromosome2) {
//				double f1 =  fChromosomeComposant(chromosome1);
//				double f2 =  fChromosomeComposant(chromosome2);
//				if (f1>f2)
//					return 1;
//				else if (f1==f2)
//					return 0;
//				else
//					return -1;
//					
//			}
//		});
//		int index = populationAsList.size()-n;
//		index = (index<0)?0:index;
//		List<Set<Set<Clazz>>> subList = populationAsList.subList(index, populationAsList.size());
//		Set<Set<Set<Clazz>>> populationAsSet = new HashSet<Set<Set<Clazz>>>(subList);
//		return populationAsSet;
//	}
//	
//	public static double fChromosomeComposant(Set<Set<Clazz>> chromosome) {
//		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
//		Collections.sort(chromosomeAsList, new Comparator<Set<Clazz>>() {
//			@Override
//			public int compare(Set<Clazz> cluster1, Set<Clazz> cluster2) {
//				double f1 =  Metrics.f(cluster1);
//				double f2 =  Metrics.f(cluster2);
//				if (f1>f2)
//					return 1;
//				else if (f1==f2)
//					return 0;
//				else
//					return -1;
//					
//			}
//		});
//		double mediane = Metrics.f(chromosomeAsList.get(chromosomeAsList.size()/2));
//		double f = 0;
////		double f2 = 0;
////		double f3 = 0;
//		int numberOfClasses = 0;
//		for (Set<Clazz> cluster : chromosome) {
//			f += Metrics.f(cluster)*cluster.size();
//			numberOfClasses += cluster.size();
//		}
////		for (Set<Clazz> cluster : chromosome) {
////			f2 += ((double)cluster.size())/((double)numberOfClasses);
////		}
//		f /= numberOfClasses;
////		f2 /= chromosome.size();
////		if (f2>=0 && f2<=0.5) {
////			f2 = 2 * f2;
////		} else {
////			f2 = 2 * (1 - f2);
////		}
////		f3 = (double)chromosome.size()/(double)numberOfClasses;
////		if (f3>=0 && f3<=0.5) {
////			f3 = 2*f3;
////		} else {
////			f3 = 2*(1-f3);
////		}
////		int coef1 = 40;
////		int coef2 = 20;
////		int coef3 = 0;
//		
////		return (coef1*f + coef2*f2 + coef3*f3) / (coef1 + coef2 + coef3);
////		return (mediane + f) / 2;
//		return f;
//		//return (Math.min(mediane, f));
//	}
//	
//	public static double fPopulation(Set<Set<Set<Clazz>>> population) {
//		double f = 0;
//		for (Set<Set<Clazz>> chromosome : population) {
//			f += fChromosomeComposant(chromosome);
//		}
//		f/=population.size();
//		return f;
//	}
//	
//	public static Set<Set<Clazz>> bestChromosome(Set<Set<Set<Clazz>>> population) {
//		return new ArrayList<Set<Set<Clazz>>>(population).get(0);
//	}
	
	public static List<Set<Set<Clazz>>> initialPopulation(Set<Clazz> clazzes, int numberOfChromosomes) {
		List<Set<Set<Clazz>>> population = new ArrayList<Set<Set<Clazz>>>();
		
		for (int i=0;i<=numberOfChromosomes;i++) {
			Random random = new Random();
			List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>();
			//générer un chromosome aléatoirement
			int nombreDeGenes = random.nextInt(clazzes.size()) + 1;///2 + 1;
			for (int j=0;j<nombreDeGenes;j++) {
				Set<Clazz> cluster = new HashSet<Clazz>();
				chromosomeAsList.add(cluster);
			}
			for (Clazz clazz : clazzes) {
				int k = random.nextInt(nombreDeGenes);
				chromosomeAsList.get(k).add(clazz);
			}
		
			Set<Set<Clazz>> genesToRemove = new HashSet<Set<Clazz>>();
			for (Set<Clazz> cluster : chromosomeAsList) {
				if (cluster.size()==0) {
					genesToRemove.add(cluster);
				}
			}
			chromosomeAsList.removeAll(genesToRemove);
			Set<Set<Clazz>> chromosome = new HashSet<Set<Clazz>>(chromosomeAsList);
			population.add(chromosome);
		}
		return population;
	}
	
	public static List<Set<Set<Clazz>>> selection1(List<Set<Set<Clazz>>> populationInitiale) {
		//TODO première selection
		List<Set<Set<Clazz>>> population = new ArrayList<Set<Set<Clazz>>>(populationInitiale);
		int nombreDeChromosomes = populationInitiale.size() * 3 / 4;
		Random random = new Random();
		
			for (Set<Set<Clazz>> chromosome : populationInitiale) {
				double r = random.nextDouble();
				if (r<=fChromosomeComposant(chromosome)) {
					population.add(chromosome);
					if (population.size()==nombreDeChromosomes) {
						break;
					}
				}
				if (population.size()==nombreDeChromosomes) break;
			}
		return population;
	}
	
	public static void mutation(Set<Set<Clazz>> chromosome, double probability) {
		Random random = new Random();
		double r = random.nextDouble();
		if (r<probability) {
			double rFusion = random.nextDouble();
			if (chromosome.size()>1)
			if (rFusion<probability/3) {
				List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
				int index1 = random.nextInt(chromosomeAsList.size());
				Set<Clazz> gene1 = chromosomeAsList.get(index1);
				int index2 = index1;
				while (index2==index1) {
					index2 = random.nextInt(chromosomeAsList.size());
				}
				Set<Clazz> gene2 = chromosomeAsList.get(index2);
				Set<Clazz> fusion = new HashSet<Clazz>(gene1);
				fusion.addAll(gene2);
				chromosome.remove(gene1);
				chromosome.remove(gene2);
				chromosome.add(fusion);
			}
			double rSeparation = random.nextDouble();
			if (rSeparation<probability/3) {
				List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
				int index = random.nextInt(chromosomeAsList.size());
				Set<Clazz> geneToSeparate = chromosomeAsList.get(index);
				List<Clazz> geneToSeparateAsList = new ArrayList<Clazz>(geneToSeparate);
				int index2 = random.nextInt(geneToSeparate.size());
				List<Clazz> gene1AsList = geneToSeparateAsList.subList(0, index2);
				List<Clazz> gene2AsList = geneToSeparateAsList.subList(index2, geneToSeparate.size());
				Set<Clazz> gene1 = new HashSet<Clazz>(gene1AsList);
				Set<Clazz> gene2 = new HashSet<Clazz>(gene2AsList);
				chromosome.remove(geneToSeparate);
				if (gene1.size()>0)
					chromosome.add(gene1);
				if (gene2.size()>0)
					chromosome.add(gene2);
				
			}
			double rAdaptation = random.nextDouble();
			if (rAdaptation<probability/3) {
				//adaptation
			}
		}
	}
	
	public static void mutationPopulation(List<Set<Set<Clazz>>> population,double probability) {
		for (Set<Set<Clazz>> chromosome : population) {
			mutation(chromosome,probability);
		}
	}
	
	public static void croisementChromosomes(Set<Set<Clazz>> chromosome1, Set<Set<Clazz>> chromosome2, List<Set<Set<Clazz>>> population) {
		//TODO croisement de deux chromosomes
		//TODO insertion des deux enfants dans la population
		Random random = new Random();
		Set<Set<Clazz>> enfant = new HashSet<Set<Clazz>>();
		for (Set<Clazz> gene : chromosome1) {
			Set<Clazz> geneEnfant = new HashSet<Clazz>();
			geneEnfant.addAll(gene);
			enfant.add(geneEnfant);
		}
		List<Set<Clazz>> chromosome2AsArrayList = new ArrayList<Set<Clazz>>(chromosome2);
		Set<Clazz> gene2 = chromosome2AsArrayList.get(random.nextInt(chromosome2.size()));
		for (Clazz clazz : gene2) {
			for (Set<Clazz> geneEnfant : enfant) {
				if (geneEnfant.contains(clazz)) {
					geneEnfant.remove(clazz);
				}
			}
		}
		enfant.add(gene2);

		Set<Set<Clazz>> enfantPropre = new HashSet<Set<Clazz>>();
		for (Set<Clazz> gene : enfant) {
			if (gene.size()>0) {
				enfantPropre.add(gene);
			}
		}
		
		population.add(enfantPropre);
	}
	
	public static void croisement(List<Set<Set<Clazz>>> population) {
		List<Set<Set<Clazz>>> populationAsArrayList = new ArrayList<Set<Set<Clazz>>>(population);
		for (int i=0;i<populationAsArrayList.size();i++)
			for (int j=i+1;j<populationAsArrayList.size();j++) {
				croisementChromosomes(populationAsArrayList.get(i), populationAsArrayList.get(j), population);
				croisementChromosomes(populationAsArrayList.get(j), populationAsArrayList.get(i), population);
			}
	}
	
	public static List<Set<Set<Clazz>>> selection2(List<Set<Set<Clazz>>> populationAsList, int n) {
		//TODO 2eme selection qui selection les n individus les plus adaptés
		Collections.sort(populationAsList, new Comparator<Set<Set<Clazz>>>() {
			@Override
			public int compare(Set<Set<Clazz>> chromosome1, Set<Set<Clazz>> chromosome2) {
				double f1 =  fChromosomeComposant(chromosome1);
				double f2 =  fChromosomeComposant(chromosome2);
				if (f1>f2)
					return 1;
				else if (f1==f2)
					return 0;
				else
					return -1;
					
			}
		});
		int index = populationAsList.size()-n;
		index = (index<0)?0:index;
		List<Set<Set<Clazz>>> subList = populationAsList.subList(index, populationAsList.size());
		return subList;
	}
	
	public static double fChromosomeComposant(Set<Set<Clazz>> chromosome) {
		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
		Collections.sort(chromosomeAsList, new Comparator<Set<Clazz>>() {
			@Override
			public int compare(Set<Clazz> cluster1, Set<Clazz> cluster2) {
				double f1 =  Metrics.f(cluster1);
				double f2 =  Metrics.f(cluster2);
				if (f1>f2)
					return 1;
				else if (f1==f2)
					return 0;
				else
					return -1;
					
			}
		});
		double mediane = Metrics.f(chromosomeAsList.get(chromosomeAsList.size()/2));
		double f = 0;
//		double f2 = 0;
//		double f3 = 0;
		int numberOfClasses = 0;
		for (Set<Clazz> cluster : chromosome) {
			f += Metrics.f(cluster);//*cluster.size();
//			numberOfClasses += cluster.size();
		}
//		for (Set<Clazz> cluster : chromosome) {
//			f2 += ((double)cluster.size())/((double)numberOfClasses);
//		}
		f /= chromosome.size();//numberOfClasses;
//		f2 /= chromosome.size();
//		if (f2>=0 && f2<=0.5) {
//			f2 = 2 * f2;
//		} else {
//			f2 = 2 * (1 - f2);
//		}
//		f3 = (double)chromosome.size()/(double)numberOfClasses;
//		if (f3>=0 && f3<=0.5) {
//			f3 = 2*f3;
//		} else {
//			f3 = 2*(1-f3);
//		}
//		int coef1 = 40;
//		int coef2 = 20;
//		int coef3 = 0;
		
//		return (coef1*f + coef2*f2 + coef3*f3) / (coef1 + coef2 + coef3);
//		return (mediane + f) / 2;
		//return f;
		double nbr = 0;
		for (Set<Clazz> cluster : chromosome) {
			if (Metrics.f(cluster)>0.65) {
				nbr++;
			}
		}
		nbr /= chromosome.size();
		return nbr;
		//return (Math.min(mediane, f));
	}
	
	public static double fPopulation(List<Set<Set<Clazz>>> population) {
		double f = 0;
		for (Set<Set<Clazz>> chromosome : population) {
			f += fChromosomeComposant(chromosome);
		}
		f/=population.size();
		return f;
	}
	
	public static Set<Set<Clazz>> bestChromosome(List<Set<Set<Clazz>>> population) {
		return new ArrayList<Set<Set<Clazz>>>(population).get(0);
	}
	
}
