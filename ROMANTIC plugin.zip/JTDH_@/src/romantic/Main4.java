package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.Set;


import org.apache.commons.io.FileUtils;

import romantic.clustering.ClusteringUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;


public class Main4 {
	public static void main(String[] args) throws IOException {
		double t = 0.2;
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("system.txt")));
//		Set<Set<Clazz>> clusters = ClusteringUtils.clustering2(oosystem.getClazzes(), t , -1);
//		ClusteringUtils2.printClusters(clusters, new PrintStream(new FileOutputStream("clusters.txt")));
//		
//		//statistiques sur les clusters
//		//Nombre de classes
//		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
//		//Nombre de clusters
//		System.out.println("Nombre de clusters : " + clusters.size());
//
//		//Nombre moyen de classe par clusters
////		double moyenne = 0;
////		for (Set<Clazz> cluster : clusters) {
////			moyenne += cluster.size();
////		}
////		moyenne /=clusters.size();
//		double moyenne = oosystem.getClazzes().size();
//		moyenne /= clusters.size();
//		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
//		//Nombre maximale de classes par clusters
//		int max = 0;
//		for (Set<Clazz> cluster : clusters) {
//			if (cluster.size()>max) {
//				max = cluster.size();
//			}
//		}
//		System.out.println("Nombre maximal de classes par clusters : " + max);
//		

	}
}
