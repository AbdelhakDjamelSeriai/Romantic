package romantic.metrics;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import romantic.metamodel.Attribute;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;


public class Metrics {
	private static Map<Set<Clazz>,Double> cache = new HashMap<Set<Clazz>,Double>();
	private static Set<Set<String>> directedConnectedMethods = new HashSet<Set<String>>();
	
	private static boolean isDirectlyConnected(Set<Clazz> clazzes, Method m1, Method m2) {
			Set<Attribute> intersection = new HashSet<Attribute>(m1.getAccessedAttributes(clazzes));
			intersection.retainAll(m2.getAccessedAttributes(clazzes));
			if (!intersection.isEmpty()) { 
				Set<String> methods = new HashSet<String>();
				methods.add(m1.getName());
				methods.add(m2.getName());
				directedConnectedMethods.add(methods);
				return true;
				
			}
			//zax comment by me :)
//			Set<Method> intersection2 = new HashSet<Method>(m1.getCalledMethods());
//			intersection2.retainAll(m2.getCalledMethods());
//			if (!intersection2.isEmpty()) { 
//				return true;
//			}
			return false;
	}
	
	private static double getNonDirectlyConnected() {//zax to do : check it :)
		double nndc = 0;
		Set<String>[] directedConnectedMethodsArray = directedConnectedMethods.toArray(new HashSet[0]);
		for(int i = 0; i < directedConnectedMethodsArray.length; i++)
		{
			Set<String> m1 = directedConnectedMethodsArray[i];
			for(int j = i + 1; j < directedConnectedMethodsArray.length; j++)
			{
				Set<String> m2 = new HashSet<String>(directedConnectedMethodsArray[j]);
				m2.retainAll(m1);
				if(!m2.isEmpty())
				{
					nndc++;
				}		
			}
		}
		return nndc;
}
	
	public static double lccMethods(Set<Clazz> clazzes, Set<Method> methods) {
		double ndc = 0;
		Method[] methodsArray = methods.toArray(new Method[0]);
		for (int i = 0;i<methodsArray.length;i++){
			for (int j = i+1;j<methodsArray.length;j++){
				if (isDirectlyConnected(clazzes, methodsArray[i],methodsArray[j])){
					ndc++;
				}
			}
		}
		
		double nndc = getNonDirectlyConnected();
		double np = methods.size() * (methods.size() - 1) / 2;
		if (np==0) return 0.0;
		double result = (ndc + nndc) / np;// zax : why + 0.5?
		return result;
	}
	
//	public static double tccMethods(Set<Method> methods) {
//		double ndc = 0;
//		Method[] methodsArray = methods.toArray(new Method[0]);
//		for (int i = 0;i<methodsArray.length;i++)
//			for (int j = i+1;j<methodsArray.length;j++)
//				if (isDirectlyConnected(methodsArray[i],methodsArray[j]))
//					ndc++;
//		double np = methods.size() * (methods.size() - 1) / 2;
//		if (np==0) return 0.5;
//		double result = ndc / np + 0.5;// zax : why + 0.5?
//		if (result>1.0)
//			return 1.0;
//		else
//			return result;
//	}
	
//	public static double tccClasses(Set<Clazz> clazzes) {
//		Set<Method> methods = new HashSet<Method>();
//		for (Clazz clazz : clazzes) {
//			methods.addAll(clazz.getMethods());
//		}
//		return tccMethods(methods);
//	}
	
	public static double lccClasses(Set<Clazz> clazzes){
		Set<Method> methods = new HashSet<Method>();
		for (Clazz clazz : clazzes) {
			methods.addAll(clazz.getMethods());
		}
		return lccMethods(clazzes, methods);
	}
	
	public static double f(Set<Clazz> clazzes) {
		Double c = cache.get(clazzes);
		double lcc_ = lccClasses(clazzes);
		double coubl_ = coupling(clazzes);
		double spe_= (lcc_+coubl_)/2;
		double comp_= (coubl_);
		
		if (c==null) {
			int lambda1 = 3;//1
			int lambda2 = 3;//3
			int lambda3 = 1;//3

			c = (lambda1*spe_ + lambda2*comp_)/(lambda1+lambda2);
			cache.put(clazzes, c);
			
			
//			c = (lambda1*specificity(clazzes) + lambda2*composability(clazzes) + lambda3*autonomy(clazzes))/(lambda1+lambda2+lambda3);
//			cache.put(clazzes, c);
		}
		return c;
	}
	
	public static double fAPI(Set<Clazz> clazzes) {
		Double similarity = cache.get(clazzes);
		similarity = (lccClasses(clazzes) + coupling(clazzes)) / 2;
		return similarity;
	}
	
	/*	Zax hint
	 * 
	 * TCC = Fraction of directly connected pairs of methods,
	 *       where two methods are directly connected if they are directly connected to an attribute.
	 *       A method m is directly connected to an attribute when the attribute appears within the method�s body
	 *       or within the body of a method invoked by method m directly or transitively.
	 *       
	 *       Tight class cohesion TCC = NDC/NP
	 *       
	 * LCC = Fraction of directly or transitively connected pairs of methods, 
	 *       where two methods are transitively connected if they are directly or indirectly connected to an attribute. 
	 *       A method m, directly connected to an attribute j, is indirectly connected to an attribute i 
	 *       when there is a method directly or transitively connected to both attributes i and j.
	 *       
	 *       Loose class cohesion LCC = (NDC+NIC)/NP
	 *       
	 *       
	 *       TCC is in the range 0..1.
	 *       LCC is in the range 0..1. TCC<=LCC.
	 *       The higher TCC and LCC, the more cohesive the class is.
	 *       
	 *       What are good or bad values? According to the authors, 
	 *       TCC<0.5 and LCC<0.5 are considered non-cohesive classes. 
	 *       LCC=0.8 is considered "quite cohesive". 
	 *       TCC=LCC=1 is a maximally cohesive class: all methods are connected.
	 */
	
	public static double specificity(Set<Clazz> clazzes) {
		return lccClasses(clazzes)/2.0 + coupling(clazzes)/2.0;
		/*
		 * zak to do
		 * 1/4 [ 1/|IFp(clazzes)| Sum i E IFp(clazzes) {LCC(i)} + LCC(IFp(clazzes)) + LCC(clazzes) + coupling(clazzes) - 10.|IFp(clazzes)|]
		 */
	}
	
	public static double autonomy(Set<Clazz> clazzes) {
		return 1-(coupling(clazzes));
		/*
		 * zak to do
		 * -5.[ |rIF(clazzes)| + 2.|rIFv(clazzes)|] 
		 * //rIFv = requer innerface verticaly
		 * //rIF = requer innerface
		 */
	}
	
	public static double composability(Set<Clazz> clazzes) {
		return (lccClasses(clazzes));
		/*
		 * zak to do
		 * [ 1/|IF(clazzes)| Sum i E IF(clazzes) {LCC(i)} - 10.|rIFv(clazzes)|]
		 * //rIFv = requer innerface verticaly
		 */
	}
	
	public static double coupling(Set<Clazz> clazzes) {
		double numberOfInsideCalledClazzes = 0;
		Set<Clazz> calledClazzes = new HashSet<Clazz>();
		for (Clazz c : clazzes) {
			for (Method m : c.getMethods()) {
				for (Method calledM : m.getCalledMethods()) {
					calledClazzes.add(calledM.getClazz());				
				}

				for (Attribute accessedA : m.getAccessedAttributes(clazzes)) {
					calledClazzes.add(accessedA.getClazz());
				}
			}
		}
		for (Clazz calledClazz : calledClazzes) {
			if (clazzes.contains(calledClazz)) {
				numberOfInsideCalledClazzes++;
			}
		}
		if (calledClazzes.size()==0) {
			return 1;
		}
		return numberOfInsideCalledClazzes/clazzes.size();
	}
	
//	public static double coupling(Clazz clazz, Set<Clazz> clazzes) {
//		Set<Clazz> clazzes2 = new HashSet<Clazz>(clazzes);
//		clazzes2.add(clazz);
//		return coupling(clazzes2);
//	}
	
	public static double sameClassProportion(Set<Method> methods) {
		Map<Clazz,Integer> map = new HashMap<Clazz,Integer>();
		for (Method m : methods) {
			Integer i = map.get(m.getClazz());
			if (i==null) {
				map.put(m.getClazz(), 1);
			} else {
				map.put(m.getClazz(), i+1);
			}
		}
		int max = 0;
		for (Clazz clazz : map.keySet()) {
			int value = map.get(clazz);
			if (value>max) {
				max = value;
			}
		}
		double result = max;
		//result = result / map.keySet().size();
		result = result / methods.size();
		return result;
	}
	
	public static double invokedTogetherSameComponent(Set<Method> methods, Set<Set<Clazz>> clusters) {
		Map<Set<Clazz>,Integer> map = new HashMap<Set<Clazz>,Integer>();
		for (Method m : methods) {
			Set<Clazz> clusterContainingM = null;
			for (Set<Clazz> cluster : clusters) {
				if (cluster.contains(m.getClazz())) {
					clusterContainingM = cluster;
					break;
				}
			}
			Integer i = map.get(clusterContainingM);
			if (i==null) {
				map.put(clusterContainingM, 1);
			} else {
				map.put(clusterContainingM, i+1);
			}
			
		}
		int max = 0;
		for (Set<Clazz> cluster : map.keySet()) {
			int value = map.get(cluster);
			if (value>max) {
				max = value;
			}
		}
		double result = max;
		result = result / methods.size();
		return result;
	}
	
	public static double fInterfaces(Set<Method> methods,Set<Set<Clazz>> clusters) {
		return sameClassProportion(methods)/3 + /*zax lccMethods(methods)/3 +*/ invokedTogetherSameComponent(methods, clusters)/3;
		
	}
}

