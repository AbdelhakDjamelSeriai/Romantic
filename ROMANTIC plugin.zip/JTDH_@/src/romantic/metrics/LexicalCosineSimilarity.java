package romantic.metrics;

import java.util.HashSet;
import java.util.Set;

import romantic.metamodel.Attribute;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;

public class LexicalCosineSimilarity {

	public static float getCosineSimilarity(Set<Clazz> set1, Set<Clazz> set2){
		
		Set<String> s1Terms = new HashSet<String>();
    	Set<String> s2Terms = new HashSet<String>();    	
    	s1Terms= getSetTerms(set1);
    	s2Terms= getSetTerms(set2);
    	final Set<String> allTokens = new HashSet<String>();
        allTokens.addAll(s1Terms);
        final int termsInString1 = allTokens.size();
        final Set<String> secondStringTokens = new HashSet<String>();
        secondStringTokens.addAll(s2Terms);
        final int termsInString2 = secondStringTokens.size();

        //now combine the sets
        allTokens.addAll(secondStringTokens);
        final int commonTerms = (termsInString1 + termsInString2) - allTokens.size();

        //return CosineSimilarity
        return (float) (commonTerms) / (float) (Math.pow((float) termsInString1, 0.5f) * Math.pow((float) termsInString2, 0.5f));
	}
	

	public static Set<String> getSetTerms(Set<Clazz> set1){
		Set<String> sTerms=  new HashSet<String>();
		for (Clazz c:set1){
    		String[] parts = c.getName().split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])");
    		for (int i=0;i<parts.length;i++) {
    			sTerms.add(parts[i]);
			}    		
    		for(Method m:c.getMethods()){
    			String[] partsMethods = m.getName().split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])");
        		for (int j=0;j<partsMethods.length;j++) {
        			sTerms.add(partsMethods[j]);
    			}
    		}
    		for(Attribute a:c.getAttributes()){
    			String[] partsAttrs = a.getName().split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])");
        		for (int j=0;j<partsAttrs.length;j++) {
        			sTerms.add(partsAttrs[j]);
    			}
    		}
    	}
		return sTerms;
	}
	}
