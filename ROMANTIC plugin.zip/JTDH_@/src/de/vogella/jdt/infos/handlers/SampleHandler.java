
package de.vogella.jdt.infos.handlers;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.Comment;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IBinding;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.LineComment;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.ui.handlers.HandlerUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;


















import romantic.ComponentNaming;
import romantic.clustering.BinaryTree;
import romantic.clustering.ClusteringUtils;
import romantic.clustering.methods.MethodsBinaryTree;
import romantic.clustering.methods.MethodsClusteringUtils;
import romantic.metamodel.Attribute;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;
import visitors.FieldAccessVisitor;
import visitors.MethodInvocationVisitor;
import visitors.TypeDeclarationVisitor;
import visitors.VariableDeclarationFragmentVisitor;
import visitors.LineCommentVisitor;
public class SampleHandler extends AbstractHandler {
	
@SuppressWarnings("unchecked")
public Object execute(ExecutionEvent event) throws ExecutionException {
	//zax
	OOSystem oosystem = new OOSystem();
	boolean isFileCreated = false;
	
//	int packagesNum=0;
	int classesNum=0;
//	int methodsNum=0;
//	int AttributesNum=0;
//    int countClassNumber = 0;
		// Get the root of the workspace
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IWorkspaceRoot root = workspace.getRoot();
		// Get all projects in the workspace
		DirectoryDialog fileDialog = new DirectoryDialog(HandlerUtil.getActiveShell(event));
		String directory = fileDialog.open();
		IProject[] projects = root.getProjects();
		for (IProject project : projects) {
			try {
				if (project.isNatureEnabled("org.eclipse.jdt.core.javanature") && project.isOpen()) {
					IJavaProject javaProject = JavaCore.create(project);
					Element xmlroot = new Element("Project");
					Document doc = new Document(xmlroot);
					xmlroot.setAttribute("ProjectName", javaProject.getElementName());
					Element xmlPackages = new Element("Packages");
					xmlroot.addContent(xmlPackages);
					for (IPackageFragment packageFragment : javaProject.getPackageFragments()) {
						if (packageFragment.getKind() == IPackageFragmentRoot.K_SOURCE && !packageFragment.getElementName().equals("")) {
							Element xmlPackage = new Element("Package");
							xmlPackages.addContent(xmlPackage);
							xmlPackage.setAttribute("PackageName", packageFragment.getElementName());
//							++packagesNum;
							Element xmlClasses = new Element("Classes");
							xmlPackage.addContent(xmlClasses);
							for (ICompilationUnit compilationUnit : packageFragment.getCompilationUnits()) {
									ASTParser parser = ASTParser.newParser(AST.JLS4);
									parser.setSource(compilationUnit);
									parser.setKind(ASTParser.K_COMPILATION_UNIT);
									parser.setEnvironment(null, new String[]{"D:/Study/EclipseWarkSpace"}, null, false);
									parser.setProject(javaProject);
									parser.setResolveBindings(true);
									parser.setBindingsRecovery(true);
									final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
									TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
									cu.accept(typeDeclarationVisitor);
									
									for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
										Element xmlClass = new Element("Class");
										xmlClasses.addContent(xmlClass);
										xmlClass.setAttribute("ClassName", typeDeclaration.getName().getFullyQualifiedName());
										
										++classesNum;
										if (Modifier.isPublic(typeDeclaration.resolveBinding().getModifiers())) {
											xmlClass.setAttribute("classAccessLevel", "public");
										} else
										if (Modifier.isProtected(typeDeclaration.resolveBinding().getModifiers())) {
											xmlClass.setAttribute("classAccessLevel", "protected");
										} else
										if (Modifier.isPrivate(typeDeclaration.resolveBinding().getModifiers())) {
											xmlClass.setAttribute("classAccessLevel", "private");
										}				
										xmlClass.setAttribute("isInterface",String.valueOf(typeDeclaration.isInterface()));
																			
										if (typeDeclaration.resolveBinding().getSuperclass()!=null) 
										{
											xmlClass.setAttribute("Superclass",typeDeclaration.resolveBinding().getSuperclass().getPackage().getName()+"@"+typeDeclaration.resolveBinding().getSuperclass().getName());
										}
										else 
											xmlClass.setAttribute("Superclass","");
										
										//zax
										String classFullName = typeDeclaration.resolveBinding().getQualifiedName();
										Clazz clazz = oosystem.getClazzByName(classFullName);
										if (clazz==null) {
											clazz = new Clazz(typeDeclaration.resolveBinding().getQualifiedName());
											oosystem.add(clazz);
										}
										
										Element xmlInterfaces = new Element("SuperInterfaces");
										xmlClass.addContent(xmlInterfaces);
										
										for (ITypeBinding itf : typeDeclaration.resolveBinding().getInterfaces()) {
											Element xmlInterface = new Element("Interface");
											xmlInterfaces.addContent(xmlInterface);
											xmlInterface.setAttribute("InterfaceName",itf.getName());
										}
										Element xmlFields = new Element("Attributes");
										xmlClass.addContent(xmlFields);
										
										for (FieldDeclaration fieldDeclaration : typeDeclaration.getFields()) {
											
											for (VariableDeclarationFragment variable : (List<VariableDeclarationFragment>)fieldDeclaration.fragments()) {
												Element xmlField = new Element("Attribute");
												xmlFields.addContent(xmlField);
//												++AttributesNum;
												xmlField.setAttribute("AttributeName", variable.getName().getFullyQualifiedName());
												
												//System.out.println(variable.resolveBinding().getModifiers());
												if (variable.resolveBinding()!=null)
												{
												
										    	if (Modifier.isPublic(variable.resolveBinding().getModifiers())) 
												{
													xmlField.setAttribute("AttributeAccessLevel", "public");
												} else
												if (Modifier.isProtected(variable.resolveBinding().getModifiers())) 
												{
													xmlField.setAttribute("AttributeAccessLevel", "protected");
												} else
												if (Modifier.isPrivate(variable.resolveBinding().getModifiers())) 
												{
													xmlField.setAttribute("AttributeAccessLevel", "private");
												}
										    	
													
											  
												xmlField.setAttribute("AttributeType", variable.resolveBinding().getType().getName());
												xmlField.setAttribute("isStaticAttribute",String.valueOf(Modifier.isStatic(variable.resolveBinding().getModifiers())));
												xmlField.setAttribute("AttributFullPath", typeDeclaration.resolveBinding().getPackage().getName()+"@"+typeDeclaration.resolveBinding().getName()+"@"+variable.getName().getFullyQualifiedName());
												
												}
											}	
										}
										Element xmlMethods = new Element("Methods");
										xmlClass.addContent(xmlMethods);
										for (MethodDeclaration methodDeclaration : typeDeclaration.getMethods()) {
											Element xmlMethod = new Element("Method");
											xmlMethods.addContent(xmlMethod);
//											++methodsNum;
											xmlMethod.setAttribute("MethodName",classFullName + "." + methodDeclaration.resolveBinding().getName());
											
											//zax
											boolean isPublic = false;
											
											if (Modifier.isPublic(methodDeclaration.resolveBinding().getModifiers())) {
												xmlMethod.setAttribute("MethodAccessLevel", "public");
												isPublic = true;
											} else
											if (Modifier.isProtected(methodDeclaration.resolveBinding().getModifiers())) {
												xmlMethod.setAttribute("MethodAccessLevel", "protected");
											} else
											if (Modifier.isPrivate(methodDeclaration.resolveBinding().getModifiers()))
											{
												xmlMethod.setAttribute("MethodAccessLevel", "private");
											}
											//else
										
											if(methodDeclaration.getBody()!=null)
											{
											xmlMethod.setAttribute("MethodBody",methodDeclaration.getBody().statements().toString());//  .statements().toString());
											}
													
											xmlMethod.setAttribute("MethodReturnType",methodDeclaration.resolveBinding().getReturnType().getName());
											xmlMethod.setAttribute("isStaticMethod",String.valueOf(Modifier.isStatic(methodDeclaration.resolveBinding().getModifiers())));
											
											//zax
											String methodFullName = classFullName + "." + methodDeclaration.resolveBinding().getName();
											Method method = clazz.getMethodByName(methodFullName);
											if (method==null) {
												method = new Method(methodDeclaration.resolveBinding().getName(),clazz);
												method.setPublicFlag(isPublic);
												clazz.addMethod(method);
											}
											
											Element xmlParameters = new Element("Parameters");
											xmlParameters.setAttribute("NumberOfParameters", String.valueOf(methodDeclaration.parameters().size()));
											xmlMethod.addContent(xmlParameters);
											for (SingleVariableDeclaration singleVariableDeclaration : (List<SingleVariableDeclaration>)methodDeclaration.parameters()) {
												Element xmlParameter = new Element("Parameter");
												xmlParameters.addContent(xmlParameter);
												xmlParameter.setAttribute("ParameterName", singleVariableDeclaration.getName().getFullyQualifiedName());
												xmlParameter.setAttribute("ParameterType", singleVariableDeclaration.resolveBinding().getType().getName());
											}
											
											Element xmlVariableDeclarations = new Element("LocalVariables");
											xmlMethod.addContent(xmlVariableDeclarations);
											VariableDeclarationFragmentVisitor variableDeclarationFragmentVisitor = new VariableDeclarationFragmentVisitor();
											methodDeclaration.accept(variableDeclarationFragmentVisitor);
											for (VariableDeclarationFragment variableDeclarationFragment : variableDeclarationFragmentVisitor.getVariables()) {
											    if(variableDeclarationFragment.resolveBinding()!=null){
											    variableDeclarationFragment.resolveBinding().getName();
												Element xmlVariableDeclaration = new Element("LocalVariable");
												xmlVariableDeclarations.addContent(xmlVariableDeclaration);
												xmlVariableDeclaration.setAttribute("LocalVariableName", variableDeclarationFragment.getName().toString());
												xmlVariableDeclaration.setAttribute("LocalVariableType", variableDeclarationFragment.resolveBinding().getType().getName());
											    }
											}
											
											
											
											Element xmlMethodInvocations = new Element("MethodInvocations");
											xmlMethod.addContent(xmlMethodInvocations);
											MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
											methodDeclaration.accept(methodInvocationVisitor);
											
											for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods())
											{
									
												//zax
												String calledClassName = "";
												String calledMethodName;
												
												Element xmlMethodInvocation = new Element("MethodInvocation");
												
												IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
												if (methodBinding!=null){
											   // if (methodInvocation.resolveTypeBinding()!=null &&  methodInvocation.resolveTypeBinding().getDeclaringClass()!=null && methodInvocation.resolveTypeBinding().getDeclaringClass().getName()!=null)
													calledClassName = methodInvocation.resolveMethodBinding().getDeclaringClass().getPackage().getName()+"."+methodInvocation.resolveMethodBinding().getDeclaringClass().getName();
													if(calledClassName.startsWith("java")){
														continue;
													}
													xmlMethodInvocation.setAttribute("DeclaredClass", calledClassName);
												} else {
											       	//xmlMethodInvocation.setAttribute("DeclaredClass",methodInvocation.getName().toString());   
												    xmlMethodInvocation.setAttribute("DeclaredClass","");
												}
												
												if (!methodInvocation.getName().toString().equals("println") && !methodInvocation.getName().toString().equals("print") && !(methodInvocation.arguments().toString().length()>=40))
												{
													
													
												
												xmlMethodInvocations.addContent(xmlMethodInvocation);
												//zax
												calledMethodName = methodInvocation.getName().toString();
												xmlMethodInvocation.setAttribute("MethodInvocationName", calledMethodName);
												xmlMethodInvocation.setAttribute("AccessedIn",methodInvocation.arguments().toString());

												//zax
												String calledMethodFullName = calledClassName + "." + calledMethodName;
												Clazz calledClazz = oosystem.getClazzByName(calledClassName);
												Method calledMethod;
												
												if (calledClazz==null) {
													calledClazz = new Clazz(calledClassName);
													oosystem.add(calledClazz);
													calledMethod = new Method(calledMethodFullName, calledClazz);
//													calledMethod.setPublicFlag(isPublic);
													calledClazz.addMethod(calledMethod);
												} else {
													calledMethod = calledClazz.getMethodByName(calledMethodFullName);
													if (calledMethod==null) {
														calledMethod = new Method(calledMethodFullName, calledClazz);
//														calledMethod.setPublicFlag(isPublic);
														calledClazz.addMethod(calledMethod);
													}
												}
												method.addCalledMethod(calledMethod);
											}
											}
											

											Element xmlFieldAccesses = new Element("FieldAccesses");
											xmlMethod.addContent(xmlFieldAccesses);
											FieldAccessVisitor fieldAccessVisitor = new FieldAccessVisitor();
											methodDeclaration.accept(fieldAccessVisitor);
											for (SimpleName fieldName : fieldAccessVisitor.getFields())
											{
												
												if(!fieldName.toString().contains("out") && !fieldName.toString().contains("err"))	
												{
													//zax
													String variableBindingClassName = "";
													String variableBindingName = "";
													
												Element xmlFieldAccess = new Element("FieldAccess");
												xmlFieldAccesses.addContent (xmlFieldAccess);
												xmlFieldAccess.setAttribute("FieldAccessName", fieldName.toString());
												//zax
												variableBindingName = fieldName.toString();
												
												IVariableBinding variableBinding = (IVariableBinding) fieldName.resolveBinding();
												if(variableBinding!=null)
												{
													if (variableBinding.getDeclaringClass()!=null ){
														variableBindingClassName = variableBinding.getDeclaringClass().getPackage().getName()+"."+variableBinding.getDeclaringClass().getName();
														 xmlFieldAccess.setAttribute("FieldDeclared", variableBindingClassName);
														 
														//zax
															String variableBindingFullName = variableBindingClassName + "." + variableBindingName;
															Clazz calledClazz = oosystem.getClazzByName(variableBindingClassName);
															
															Attribute accessedAttribute;
															
															if (calledClazz==null) {
																calledClazz = new Clazz(variableBindingClassName);
																if(!variableBindingFullName.startsWith("java")){
																	oosystem.add(calledClazz);
																}
																accessedAttribute = new Attribute(variableBindingFullName, calledClazz);
																calledClazz.addAttribute(accessedAttribute);
															} else {
																// la classe existe dans le systeme
																accessedAttribute = calledClazz.getAttributeByName(variableBindingFullName);
																if (accessedAttribute==null) {
																	accessedAttribute = new Attribute(variableBindingFullName, calledClazz);
																calledClazz.addAttribute(accessedAttribute);
																}
															}
															
															method.addAccessedAttribute(accessedAttribute);
														 
													}else
														 //xmlFieldAccess.setAttribute("FieldDeclared", fieldName.toString());	
													     xmlFieldAccess.setAttribute("FieldDeclared", "");
												}
												   else
													  // xmlFieldAccess.setAttribute("FieldDeclared", fieldName.toString());	
													   xmlFieldAccess.setAttribute("FieldDeclared", "");
												}	
											
											}
											
										
										/*	Element xmlCommentDeclarations = new Element("BlockComments");
											xmlMethod.addContent(xmlCommentDeclarations);
											LineCommentVisitor lineCommentVisitor = new LineCommentVisitor();
											methodDeclaration.accept(lineCommentVisitor);
										  //  BodyDeclaration h ;
										  //  h.getJavadoc();
										
											//System.out.print(typeDeclaration.getJavadoc());
											
											//List<Comment> vvv= new ArrayList<Comment>();
											//vvv=lineCommentVisitor.getComments();
											//System.out.println(cu.getCommentList().size());
											//System.out.println(cu.getCommentList().get(0));
										//	for (Object object : cu.getCommentList()) {
									    	for (Object object : cu.getCommentList()) {
												Comment comment = (Comment) object;
												//if(comment.getClass().getName().equals(LineComment.class.getName())) {
												if(comment.isLineComment()) {
													//comment.accept(variableDeclarationFragmentVisitor);
													//LineComment lineComment = (LineComment) comment;
													Element xmlBlockCommentDeclaration = new Element("LineComment");
													xmlCommentDeclarations.addContent(xmlBlockCommentDeclaration);
													
													xmlBlockCommentDeclaration.setAttribute("CommentValue",comment. toString());
													
													
												}
												
												System.out.println("ffffffff");
												
											   }*/
										
											Element xmlMethodExceptions = new Element("MethodExceptions");
											xmlMethod.addContent(xmlMethodExceptions);
											for (ITypeBinding exceptions : methodDeclaration.resolveBinding().getExceptionTypes()) {
												Element xmlMethodException = new Element("Exception");
												xmlMethodExceptions.addContent(xmlMethodException);
												xmlMethodException.setAttribute("ExceptionType", exceptions.getName());	
											}
										}
									}	
							}
						}
					}
					
//					String packagesNumber=Integer.toString(packagesNum);
					String classesNumber=Integer.toString(classesNum);
//					String MethodsNumber=Integer.toString(methodsNum);
//					String AttributesNumber=Integer.toString(AttributesNum);
					
					Element xmlProjectDetails = new Element("xmlProjectInfo");
//					
					xmlroot.addContent(xmlProjectDetails);
//					xmlProjectDetails.setAttribute("NumberofPackages",packagesNumber);
					xmlProjectDetails.setAttribute("NumberofClasses", classesNumber);
//					xmlProjectDetails.setAttribute("NumberofMethods",MethodsNumber);
//					xmlProjectDetails.setAttribute("NumberofAttributes",AttributesNumber);
					
					//Write results
					if(!isFileCreated){
					Date date = new Date();
					directory += "/" + " results "+date.getDate() + " " + date.getTime();
					File file = new File(directory);
					file.mkdir();
					isFileCreated = true;
					}
					if (directory!=null) {
						XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
						outputter.output(doc, new FileOutputStream(directory + "/" + project.getName() + " parser.xml"));	
						classesNum = 0;
					}
					
				}//end if
			} //end try
			
			catch (FileNotFoundException e) {
			e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JavaModelException e) {
				e.printStackTrace();
			} catch (CoreException e) {
				e.printStackTrace();
			}
		
			
		}//end loop project
		
		//zax preak point
//		System.exit(0);
		
		//Apply ROMANTIC
		//Identify components
		BinaryTree binaryTree = ClusteringUtils.clustering(oosystem.getClazzes());
		Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
		
		//Identify Interfaces
//				for (Set<Clazz> cluster : clusters) {
//					Set<Method> methods = new HashSet<Method>();
//					for (Clazz c : cluster) {
//						for (Method m : c.getMethods()) {
//							for (Method calledM : m.getCalledMethods()) {
//								if (!cluster.contains(calledM.getClazz())) {
//									methods.add(calledM);
//								}
//							}
//						}
//					}
//					if (methods.size()!=0) {
//					MethodsBinaryTree clustering = MethodsClusteringUtils.clustering(methods,clusters);
//					Set<Set<Method>> methodsClusters = MethodsClusteringUtils.parcoursDendrogramme(clustering, 0.425,clusters);
//					try {
//						MethodsClusteringUtils.printClusters(methodsClusters, clusters, new PrintStream(new FileOutputStream(directory + "/" + ComponentNaming.componentName(cluster) + ".txt")));
//					} catch (FileNotFoundException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					}
//				}
//		
		
		
		//Write results
		try {
			ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream(directory + "/clusters.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		//consol results
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
		
		return null;
	}

}
