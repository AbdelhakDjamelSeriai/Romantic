package visitors;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.BlockComment;

public class BlockCommentVisitor extends ASTVisitor {
         List<BlockComment> comments = new ArrayList<BlockComment>();

        public boolean visit(BlockComment node) {
                comments.add(node);
                return super.visit(node);
        }

        public  List<BlockComment> getComments() {
                return comments;
        }
}
