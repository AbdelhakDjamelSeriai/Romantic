package lirmm.marel.text.clustering.algorithms;

import java.util.HashSet;
import java.util.Set;

import lirmm.marel.text.clustering.dataset.Component;

public class Leaf extends Node {
	private Component component;
	public int productID;
	public Leaf() {
		super();
	}

	public Component getDocument() {
		return this.component;
	}

	public void setClazz(Component component) {
		this.component = component;
	}

	public Leaf(Component component) {
		super();
		this.component = component;
	}
	public Leaf(Component component, int p) {
		super();
		this.productID=p;
		this.component = component;
	}
	@Override
	public Set<Component> getComponents() {
		Set<Component> comSet = new HashSet<Component>();
		comSet.add(this.component);
		return comSet;
	}
}
