package lirmm.marel.text.clustering.algorithms;

import java.util.Set;

import lirmm.marel.text.clustering.dataset.Component;


public abstract class Node {
	public abstract Set<Component> getComponents();
}
