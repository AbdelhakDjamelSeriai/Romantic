package lirmm.marel.text.clustering.algorithms;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.security.PublicKey;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

import lirmm.marel.romantic.quality.QualityFunction;
import lirmm.marel.text.clustering.dataset.Component;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.text.clustering.similarity.metric.CosineSimilarity;

public class Hierarchicalclustering {

	public static Set<Set<Component>> clusterResults = new HashSet<Set<Component>>();

	public static BinaryTree generateBinaryTreeNew(Set<Component> components) {
		Set<Node> noeuds = new HashSet<Node>();
		int taille = components.size();
		double max;
		BinaryTree b = null;
		// create leaf nodes
		for (Component component : components) {
			noeuds.add(new Leaf(component, component.getProductID()));
		}
		do {
			Node[] noeudsArray = noeuds.toArray(new Node[0]);
			Node n1 = noeudsArray[0];
			Node n2 = noeudsArray[1];

			max = -1;
			// find most similur nodes
			//Hi Anas, you can optomize the loop by devide Math.ceil(noeudsArray.length/2)
			for (int i = 0; i < noeudsArray.length; i++) {
				for (int j = i + 1; j < noeudsArray.length; j++) {
					
					double value = CosineSimilarity.getSimilarityBetweenSets(
							noeudsArray[i].getComponents(),
							noeudsArray[j].getComponents());
					if (!isNodesBelongToSameProduct(noeudsArray[i], noeudsArray[j])){
//						value=0;
					}
					if (value > max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
						
						// chech if they belong to the same product
					}
				}
			}
			b = new BinaryTree();
			b.setNode1(n1);
			b.setNode2(n2);
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
		} while (b.numberOfLeaves() != taille);
		return b;
	}

	public static Set<Set<Component>> parcoursDendrogramme(
			BinaryTree dendrogramme, double t) {
		Set<Set<Component>> result = new HashSet<Set<Component>>();
		Stack<Node> pile = new Stack<Node>();
		pile.push(dendrogramme);
		int counter = 0;
		
		while (!pile.isEmpty()) {
			counter++;
			Node pere = pile.pop();
			Set<Component> pereCluster = pere.getComponents();
			if (pere instanceof BinaryTree) {
				Set<Component> fils1Cluster = (((BinaryTree) pere).getNode1()
						.getComponents());
				Set<Component> fils2Cluster = (((BinaryTree) pere).getNode2()
						.getComponents());
				double valuePere = CosineSimilarity.getSimilarityBetweenSets(
						fils1Cluster, fils2Cluster);
				System.out.println(((BinaryTree) pere).numberOfLeaves() + " : valuePere = " + valuePere);
				Node leftNode;
				Node rightNode;
				leftNode = ((BinaryTree) pere).getNode1();
				rightNode = ((BinaryTree) pere).getNode2();
				double valueFils1 = CosineSimilarity
						.getSimilarityNode(leftNode);
				System.out.println(((BinaryTree) pere).numberOfLeaves() + " :valueFils1 = " + valueFils1);
//				;
				double valueFils2 = CosineSimilarity
						.getSimilarityNode(rightNode);
				System.out.println(((BinaryTree) pere).numberOfLeaves() + " : valueFils2 = " + valueFils2);
//				;
				if (valuePere > (valueFils1 + valueFils2) * t) {
					result.add(pereCluster);
//					if (valueFils1 >= valuePere) {
//						pile.add(((BinaryTree) pere).getNode1());
//					}
//					if (valueFils2 >= valuePere) {
//						pile.add(((BinaryTree) pere).getNode2());
//					}
				} else {
					pile.add(((BinaryTree) pere).getNode1());
					pile.add(((BinaryTree) pere).getNode2());
				}

			} else {
				result.add(pereCluster);
			}
		}
		return result;

	}
	
	public static boolean isNodesBelongToSameProduct(Node n1, Node n2){
		Set<Component> n1Compo= n1.getComponents();
		Set<Component> n2Compo= n2.getComponents();
		for (Component com1: n1Compo){
			for (Component com2: n2Compo){
				if (com1.getProductID() == com2.getProductID()){
					return true;
				}
			}
		}
		return false;
	}

	public static void printClusters(Set<Set<Component>> clusters,
			PrintStream out) {
		int i = 1;
		for (Set<Component> cluster : clusters) {
			 out.println("Cluster " + i + "(" + cluster.size()+" classes) " 
//			+
			// "specificity : " +
			// Metrics.specificity(cluster)+" composability : " +
			// Metrics.composability(cluster) + " autonomy : " +
			// Metrics.autonomy(cluster));
			// out.println("Component Name : " +
			// ComponentNaming.componentName(cluster)
					 );
			out.println(".......................................");
			for (Component doc : cluster) {
				out.println("" + doc.getTitle());
			}
			i++;
		}
	}

	public static void printClusterDetails(Set<Set<Component>> clusters)
			throws FileNotFoundException {
		PrintStream out = new PrintStream(new FileOutputStream(
				"clustersDetails.txt"));
		int i = 1;
		for (Set<Component> cluster : clusters) {
			// out.println("Cluster " + i + "(" + cluster.size()+" classes) " +
			// "specificity : " +
			// Metrics.specificity(cluster)+" composability : " +
			// Metrics.composability(cluster) + " autonomy : " +
			// Metrics.autonomy(cluster));
			// out.println("Component Name : " +
			// ComponentNaming.componentName(cluster));
			if (calculateCommonClasses(cluster) == null) {
//				continue;
			}
			out.println("***********************************************************************************************************************************************");
			out.println();
			out.println("Cluster  number: " + i + "(" + cluster.size()
					+ " components)");
			out.println();

			// out.println("Common Classes xxxxxxx: ");
			// out.println(calculateCommonClasses1111(cluster));

			out.println("Common Classes : ");
			out.println(calculateCommonClasses(cluster));
			out.println();
			out.println("Variable Classes : ");
			out.println(calculateVariableClasses(cluster));
			out.println();
			out.println("=================================================================================================");
			for (Component doc : cluster) {
				// out.println("" + doc.getTitle());
				out.println("..................................................................");
				out.println("From Product # " + doc.getProductID());
				out.println("Component name: " + doc.getTitle() + " F:"
						+ QualityFunction.QualityFun(doc.getClasses()));
//						"  S:"
//						+ Metrics.specificity(doc.getClasses()) + " A:"
//						+ Metrics.autonomy(doc.getClasses()) + " C:"
//						+ Metrics.composability(doc.getClasses()));
				out.println("" + doc.getTerms());
			}
			i++;
		}

	}

	public static String calculateCommonClasses(Set<Component> cluster) {
		String commonClasses = "";
		Set<String> union = new HashSet<String>();
		Set<String> intersect = new HashSet<String>();
		Set<String> difference = new HashSet<String>();
		int i = 0;
		for (Component doc : cluster) {
			if (i == 0) {
				intersect.addAll(doc.getTerms());
				i = 1;
			}
			union.addAll(doc.getTerms());
			intersect.retainAll(doc.getTerms());
		}
		difference.addAll(union);
		difference.removeAll(intersect);
		commonClasses = intersect.toString();
		if (intersect.size() == 0) {
			commonClasses = null;
		}
		return commonClasses;
	}

	public static String calculateVariableClasses(Set<Component> cluster) {
		String commonClasses = "";
		Set<String> union = new HashSet<String>();
		Set<String> intersect = new HashSet<String>();
		Set<String> difference = new HashSet<String>();
		int i = 0;
		for (Component doc : cluster) {
			if (i == 0) {
				intersect.addAll(doc.getTerms());
				i = 1;
			}
			union.addAll(doc.getTerms());
			intersect.retainAll(doc.getTerms());
		}
		difference.addAll(union);
		difference.removeAll(intersect);
		commonClasses = difference.toString();
		return commonClasses;
	}
}
