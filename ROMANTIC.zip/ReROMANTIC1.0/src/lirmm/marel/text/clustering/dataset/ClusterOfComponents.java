package lirmm.marel.text.clustering.dataset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;


import lirmm.marel.romantic.documentation.ComponentNaming;
import lirmm.marel.romantic.main.Main;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.romantic.util.Constant;

public class ClusterOfComponents {
	Set<Component> components;
	Set<Component> finalResultComponents;
	Set<Class> commonClasses = new HashSet<Class>();
	Set<Class> allClasses = new HashSet<Class>();
	Set<Class> sharedClassesInAllProducts = new HashSet<Class>();
	Set<Class> nonSharedClassesInAllProducts = new HashSet<Class>();
	Set<Class> variableClasses = new HashSet<Class>();
	Set<Integer> productIDs = new HashSet<Integer>();
	public String nameOfCommon[];
	public String nameOfVariable[];
	public double thresholdofFF = 0.50;

	public ClusterOfComponents() {
		components = new HashSet<Component>();
		finalResultComponents = new HashSet<Component>();
	}

	public void addComponent(Component component) {
		this.components.add(component);
	}

	public Set<Component> getComponents() {
		return components;
	}

	public void findIDofProductmember() {

		for (Component compo : components) {
			productIDs.add(compo.getProductID());
		}

	}

	public void findSharedClassesInProdycts() {
		findIDofProductmember();
		for (Class c : variableClasses) {
			if (isClassbelongtoAllProducts(c)) {
				sharedClassesInAllProducts.add(c);
			} else {
				nonSharedClassesInAllProducts.add(c);
			}
		}

	}

	public void identifyFinalSetofComponents() {
		// claculateCommonVariableSetsClasses();

		// Clazz[] shared = sharedClassesInAllProducts.toArray(new Clazz[0]);
		// System.err.println("print shared array");
		// for (Clazz c : shared) {
		// System.err.println(c.getName());
		// }
		Component tempComponenet = new Component(0,
				ComponentNaming.componentName(allClasses), allClasses);
		if (tempComponenet.getFF() >= Constant.thresholdofFF) {
			finalResultComponents.add(tempComponenet);
		}
	}

	// print all subsets of the remaining elements, with given prefix
	private void combination(HashSet<Class> prefix, int index, Class[] classes) {
		if (index >= classes.length) {
			return;
		}

		prefix = (HashSet<Class>) prefix.clone();
		combination(prefix, index + 1, classes);

		prefix.add(classes[index]);
		HashSet<Class> tempSet = new HashSet<Class>();
		tempSet.addAll(commonClasses);
		tempSet.addAll(prefix);
		Component tempComponenet = new Component(0,
				ComponentNaming.componentName(tempSet), tempSet);

		if (tempComponenet.getFF() >= thresholdofFF) {
			finalResultComponents.add(tempComponenet);
		}
		// output.add(tempComponenet);

		combination(prefix, index + 1, classes);
	}

	private boolean isClassbelongtoAllProducts(Class c) {
		for (int i : productIDs) {

			if (!Constant.products[i].getClasses().contains(c)) {
				return false;
			}
		}
		return true;
	}

	public void claculateCommonVariableSetsClasses() {
		calculateCommonClasses();
		for (Component comp : components) {
			for (Class claz : comp.getClasses()) {
				if (isBelongtoClassesName(claz)) {	
					commonClasses.add(claz);
				} else {
					variableClasses.add(claz);
				}
				allClasses.add(claz);

			}
		}
		variableClasses.addAll(allClasses);
		variableClasses.removeAll(commonClasses);
		findSharedClassesInProdycts();
	}

	private boolean isBelongtoClassesName(Class c) {
		for (int i = 0; i < nameOfCommon.length; i++) {
			if (c.getName() == nameOfCommon[i]) {
				return true;
			}
		}
		return false;
	}

	public void calculateCommonClasses() {
		Set<String> union = new HashSet<String>();
		Set<String> intersect = new HashSet<String>();
		Set<String> difference = new HashSet<String>();
		int i = 0;
		for (Component doc : components) {
			if (i == 0) {
				intersect.addAll(doc.getTerms());
				i = 1;
			}
			union.addAll(doc.getTerms());
			intersect.retainAll(doc.getTerms());
		}
		difference.addAll(union);
		difference.removeAll(intersect);
		nameOfCommon = new String[intersect.size()];
		int j = 0;
		for (String str : intersect) {
			nameOfCommon[j++] = str;
		}
		// if (intersect.size() == 0) {
		// nameOfCommon = null;
		// }
		j = 0;
		nameOfVariable = new String[difference.size()];
		for (String str : difference) {
			nameOfVariable[j++] = str;
		}
	}

	public Set<Component> getComonents() {
		return components;
	}

	public Set<Class> getCommonClasses() {
		return commonClasses;
	}

	public Set<Class> getVariableClasses() {
		return variableClasses;
	}

	public Set<Class> getAllClasses() {
		return allClasses;
	}

	public Set<Class> getSharedClassesinProductMember() {
		return sharedClassesInAllProducts;
	}

	public Set<Class> getNonSharedClassesinProductMember() {
		return nonSharedClassesInAllProducts;
	}

	public Set<Integer> getIDsProductMember() {
		return productIDs;
	}

	public Set<Component> getFinalSetOfComponents() {
		return finalResultComponents;
	}
}
