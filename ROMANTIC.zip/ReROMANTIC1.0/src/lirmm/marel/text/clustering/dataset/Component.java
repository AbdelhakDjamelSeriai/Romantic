package lirmm.marel.text.clustering.dataset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import lirmm.marel.romantic.object.elements.Method;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.romantic.quality.QualityFunction;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class Component {
	ArrayList<String> terms;
	Set<Class> classes;
	String tilte;
	int productID;
	double ff;
	Set<Set<Method>> interfaceMethods= new HashSet<>();;

	public Component(int productID, String title, Set<Class> classes) {
		this.productID = productID;
		this.tilte = title;
		this.classes = classes;
		this.ff = QualityFunction.QualityFun(classes);
		claculateComponentTerms();
	}

	private void claculateComponentTerms() {
		this.terms = new ArrayList<String>();
		for (Class c : classes) {
			this.terms.add(c.getName());
		}
	}

	public void setTerms(ArrayList<String> t) {
		this.terms = t;
	}

	public ArrayList<String> getTerms() {
		return this.terms;
	}

	public String getTitle() {
		return tilte;
	}

	public int getProductID() {
		return this.productID;
	}
	
	public double getFF() {
		return this.ff;
	}

	public Set<Class> getClasses() {
		return this.classes;
	}

	public String toString() {
		String str = "";
		str += "\nComponent Name:" + tilte + "\n";
		for (int i = 0; i < terms.size(); i++) {
			str += terms.get(i) + "	";
		}
		str += "\n..............................................................";
		return str;
	}

}
