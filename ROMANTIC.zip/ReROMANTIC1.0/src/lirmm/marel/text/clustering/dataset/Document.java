package lirmm.marel.text.clustering.dataset;

import java.util.ArrayList;
import java.util.Vector;

public class Document {
	ArrayList<String> terms;
	String tilte;
	public Document(String title, ArrayList<String> terms) {
		this.tilte=title;
		this.terms=terms;
	}
	public void setTerms(ArrayList<String> t){
		this.terms=t;
	}
	public ArrayList<String> getTerms() {
		return this.terms;		
	}
	
	public String getTitle() {
		return tilte;		
	}
	
	public String toString(){
		String str="";
		str+= "\nDocument Name:"+tilte+"\n";
		for (int i = 0; i < terms.size(); i++) {
			str += terms.get(i) + "	";
		}
		str+= "\n..............................................................";
		return str;
	}
}
