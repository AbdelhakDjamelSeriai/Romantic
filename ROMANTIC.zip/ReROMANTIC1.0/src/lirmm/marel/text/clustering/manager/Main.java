package lirmm.marel.text.clustering.manager;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ComponentClusterManager manager= new ComponentClusterManager();
		manager.mainManager();		
	}	
}
