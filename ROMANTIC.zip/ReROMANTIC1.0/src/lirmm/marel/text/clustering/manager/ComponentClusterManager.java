package lirmm.marel.text.clustering.manager;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import lirmm.marel.romantic.documentation.DocumentationOfComponents;
import lirmm.marel.romantic.main.CrossValidation;
import lirmm.marel.romantic.quality.QualityFunction;
import lirmm.marel.romantic.util.Constant;
import lirmm.marel.text.clustering.algorithms.BinaryTree;
import lirmm.marel.text.clustering.algorithms.Hierarchicalclustering;
import lirmm.marel.text.clustering.dataset.ClusterOfComponents;
import lirmm.marel.text.clustering.dataset.Component;

public class ComponentClusterManager {
	public static Set<Set<Component>> clusters;

	public ComponentClusterManager() {
	}

	public void mainManager() {
		// ReadMultipleFiles.readFiles("res/");
		// ArrayList<Component> docs = new ArrayList<Component>();
		// docs = (ArrayList<Component>) ReadMultipleFiles.documents.clone();
		// printDocuments(docs);
		// // DFTF dftf= new DFTF(docs);
		// // dftf.calculateMatrix();
		// Set<Component> setOfDocuments = new HashSet<Component>();
		// setOfDocuments.addAll(docs);
		// startClustering(setOfDocuments);
	}

	public static void startClustering(Set<Component> documents) {
//		BinaryTree binaryTree = Hierarchicalclustering
//				.generateBinaryTreeNew(documents);
//
//		// Hierarchicalclustering.binaryTreeTravelsal(binaryTree);
//
//		clusters = Hierarchicalclustering.parcoursDendrogramme(binaryTree, 0.5);
//		// System.err.println(i+"..................................................................");
//		try {
//			Hierarchicalclustering.printClusters(clusters, new PrintStream(
//					new FileOutputStream("clusters.txt")));
//			Hierarchicalclustering.printClusterDetails(clusters);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.err.println("Nombre de classes : " + documents.size());
//		
//		System.err.println("Nombre de clusters : " + clusters.size());
//		// Hierarchicalclustering.binaryTreeTravelsal(binaryTree);
	}

	public static void startComponentClustering(Set<Component> components) {
		System.err.println("\tClustering starting...");
		BinaryTree binaryTree = Hierarchicalclustering
				.generateBinaryTreeNew(components);
		System.err.println("\tdocument clustering: binary tree built");
		clusters = Hierarchicalclustering.parcoursDendrogramme(binaryTree, 0.5);
		System.err.println("\tdocument clustering: parcoursDendrogramme"
				+ clusters.size());
		System.err.println("\t\twriting the results of components clustering...");
		try {
			Hierarchicalclustering.printClusters(clusters, new PrintStream(
					new FileOutputStream("clusters.txt")));
			Hierarchicalclustering.printClusterDetails(clusters);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.err.println("\t\tNumber of Components : " + components.size());
		System.err.println("\t\tNumber of clusters : " + clusters.size());
		ArrayList<ClusterOfComponents> clusterOfComponents = getClustersOfComponents(clusters);
		try {
			writeClusterDetails(clusterOfComponents);
			System.err.println("\t\tinitail result is writenin .../outputResults/initialResultComponentsClustering.txt");
			writeFinalResult(clusterOfComponents);
			System.err.println("\t\tfinal result is writen in .../outputResults/FinalResultOfComponentsClustering.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static ArrayList<ClusterOfComponents> getClustersOfComponents(
			Set<Set<Component>> clusters) {
		ArrayList<ClusterOfComponents> clusterOfComponents = new ArrayList<ClusterOfComponents>();
		for (Set<Component> cluster : clusters) {
			ClusterOfComponents clusterofCom = new ClusterOfComponents();
			for (Component doc : cluster) {
				clusterofCom.addComponent(doc);
			}
			clusterOfComponents.add(clusterofCom);
		}
		return clusterOfComponents;
	}

	public static void writeClusterDetails(
			ArrayList<ClusterOfComponents> clustersOfComp)
			throws FileNotFoundException {
		PrintStream out = new PrintStream(new FileOutputStream(
				"outputResults/initialResultComponentsClustering.txt"));
		int i = 1;
		for (ClusterOfComponents component : clustersOfComp) {
			component.calculateCommonClasses();
			component.claculateCommonVariableSetsClasses();
			if (component.getCommonClasses().size() == 0) {
				// continue;
			}
			out.println("***********************************************************************************************************************************************");
			out.println();
			out.println("Cluster  number: " + i + "("
					+ component.getComonents().size() + " components)");
			out.println();

			// out.println("Common Classes xxxxxxx: ");
			// out.println(calculateCommonClasses1111(cluster));
			out.println("member products" + component.getIDsProductMember());
			out.println("Common Classes : ("
					+ component.getCommonClasses().size() + ") " + " F:"
					+ QualityFunction.QualityFun(component.getCommonClasses())
					+ " all classes F:"
					+ QualityFunction.QualityFun(component.getAllClasses()));
			// out.println(component.getAllClasses());
			out.println(component.getCommonClasses());
			// out.println();
			// out.println();
			out.println();
			out.println("Variable Classes : ("
					+ component.getVariableClasses().size()
					+ ") "
					+ " F:"
					+ QualityFunction.QualityFun(component.getVariableClasses()));
			out.println(component.getVariableClasses());
			out.println();
			out.println("=================================================================================================");
			for (Component doc : component.getComonents()) {
				// out.println("" + doc.getTitle());
				out.println("..................................................................");
				out.println("From Product # " + doc.getProductID());
				out.println("Component name: " + doc.getTitle() + " F:"
						+ QualityFunction.QualityFun(doc.getClasses()));
				out.println("" + doc.getTerms());
			}
			i++;
		}

	}

	public static void writeFinalResult(
			ArrayList<ClusterOfComponents> clustersOfComp)
			throws FileNotFoundException {
		PrintStream out = new PrintStream(new FileOutputStream(
				"outputResults/FinalResultOfComponentsClustering.txt"));
		int i = 1;

		double sumOfAllCommonClasses = 0;
		double sumOfAllVarClasses = 0;

		double sumOfFFofCommonClasses = 0;
		double sumOfAllFFComponents = 0;

		double sumOfSpecofCommonClasses = 0;
		double sumOfAllSpecComponents = 0;

		double sumOfAutonomyofCommonClasses = 0;
		double sumOfAllAutonomyComponents = 0;

		double sumOfComposabilityCommonClasses = 0;
		double sumOfAllComposabilityComponents = 0;

		double totalComponentSize = 0;
		int totalNumOfComponents = 0;

		double sumOfAllComponent = 0;
		for (ClusterOfComponents clusterOfComponent : clustersOfComp) {
//			System.err.println("cluster :" + i);
			if (clusterOfComponent.getIDsProductMember().size() == 1) {
//				continue;
			}
			clusterOfComponent.calculateCommonClasses();
			// out.println("Cluster " + i + "(" + cluster.size()+" classes) " +
			// "specificity : " +
			// Metrics.specificity(cluster)+" composability : " +
			// Metrics.composability(cluster) + " autonomy : " +
			// Metrics.autonomy(cluster));
			// out.println("Component Name : " +
			// ComponentNaming.componentName(cluster));
			clusterOfComponent.claculateCommonVariableSetsClasses();
			if (clusterOfComponent.getCommonClasses().size() == 0
					&& clusterOfComponent.getSharedClassesinProductMember()
							.size() == 0) {
				// continue;
			}

			clusterOfComponent.identifyFinalSetofComponents();

			double commonSpec, commonComposability, commonAutonomy, commonFitness;
			commonFitness = QualityFunction.QualityFun(clusterOfComponent
					.getCommonClasses());
			commonSpec = QualityFunction.specFun(clusterOfComponent
					.getCommonClasses());
			commonAutonomy = QualityFunction.autFun(clusterOfComponent
					.getCommonClasses());
			commonComposability = QualityFunction.composFun(clusterOfComponent
					.getCommonClasses());

			sumOfAllVarClasses += clusterOfComponent.getVariableClasses()
					.size();

			sumOfAutonomyofCommonClasses += commonAutonomy;
			sumOfComposabilityCommonClasses += commonComposability;
			sumOfFFofCommonClasses += commonFitness;
			sumOfSpecofCommonClasses += commonSpec;
			sumOfAllCommonClasses += clusterOfComponent.getCommonClasses()
					.size();

			sumOfAllComponent += clusterOfComponent.getComonents().size();
			out.println("***********************************************************************************************************************************************");
			out.println();
			out.println("Cluster  number: " + i + "("
					+ clusterOfComponent.getComonents().size() + " components)");
			out.println();
			out.println("member products"
					+ clusterOfComponent.getIDsProductMember());
			out.println("shared classes		: ("
					+ clusterOfComponent.getSharedClassesinProductMember()
							.size() + ") "
					+ clusterOfComponent.getSharedClassesinProductMember());
			out.println("non shared claases	: ("
					+ clusterOfComponent.getNonSharedClassesinProductMember()
							.size() + ") "
					+ clusterOfComponent.getNonSharedClassesinProductMember());
			out.println("all classes		: ("
					+ clusterOfComponent.getAllClasses().size() + ") "
					+ clusterOfComponent.getAllClasses());
			out.println("Common Classes : ("
					+ clusterOfComponent.getCommonClasses().size()
					+ ") "
					+ " F:"
					+ commonFitness
					+ " all classes F:"
					+ QualityFunction.QualityFun(clusterOfComponent
							.getAllClasses()));
			// out.println(component.getAllClasses());
			out.println(clusterOfComponent.getCommonClasses());
			out.println();
			out.println("Variable Classes : ("
					+ clusterOfComponent.getVariableClasses().size()
					+ ") "
					+ " F:"
					+ QualityFunction.QualityFun(clusterOfComponent
							.getVariableClasses()));
			out.println(clusterOfComponent.getVariableClasses());
			out.println();
			out.println("Final set of component from this cluster:");
			for (Component tempCompo : clusterOfComponent
					.getFinalSetOfComponents()) {
				CrossValidation.reusableComponents.add(tempCompo);
				out.println("##############################################################");
				out.println("Component name: " + tempCompo.getTitle()
						+ " ,  Number of Classes("
						+ tempCompo.getClasses().size() + ")");
				sumOfAllFFComponents += tempCompo.getFF();

				out.println(" F:" + tempCompo.getFF()
				// + "  S:"
				// + tempCompo.getSpec() + " A:" + tempCompo.getAutonomy()
				// + " C:" + tempCompo.getComposability()
				);
				out.println("" + tempCompo.getTerms());
				totalNumOfComponents++;
				totalComponentSize += tempCompo.getClasses().size();
				// int jj = 1;
				// tempCompo.findComponentInterface();
				// for (Set<Method> interfaceMethom :
				// tempCompo.getInterfaceMethods()) {
				// out.print("interface size " + "(" + interfaceMethom.size() +
				// " method)");
				// out.println("cohesion : " +
				// Metrics.tccMethods(interfaceMethom)
				// + ", sameInterface : "
				// + Metrics.sameClassProportion(interfaceMethom)
				// + ", invokationTogether : Non");
				// for (Method method : interfaceMethom) {
				// out.print("  " + method.getClazz().getName() + "."
				// + method.getName()+ " + ");
				// }
				// out.println();
				// }
				out.println("00000000000000000000000000000000000000000000000000000000000000000");
				out.println("Decumentation of this component"
						+ tempCompo.toString());
				DocumentationOfComponents documentation = new DocumentationOfComponents(
						tempCompo);
				documentation.extractFunctionalities();
				out.println(documentation.toString());
			}
			out.println();
			out.println();

			out.println("=================================================================================================");
			for (Component component : clusterOfComponent.getComonents()) {
				// out.println("" + doc.getTitle());
				out.println("..................................................................");
				out.println("From Product # " + component.getProductID());
				out.println("Component name: " + component.getTitle() + " F:"
						+ QualityFunction.QualityFun(component.getClasses())
						+ " , " + component.getFF() + "  S:"
						+ QualityFunction.specFun(component.getClasses())
						+ " A:"
						+ QualityFunction.autFun(component.getClasses())
						+ " C:"
						+ QualityFunction.composFun(component.getClasses()));
				out.println("" + component.getTerms());

			}
			i++;
		}
		i--;
		out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
		out.println();
		out.println("Products Analysis:");
		out.println("\tnumber of variants:" + Constant.noOfPro);
		out.println("\taverage size of variants:"
		 + Constant.averageVariantSize + " classes"
		);
		out.println("\taverage num of components in variants:"
		 + Constant.averageNumberOfCompo + " components"
		);
		out.println("\taverage  components size:"
		 + Constant.averageCompoSize + " classes"
		);
		out.println();

		out.println("Components Analysis:");
		out.println("Total Number Of Components: " + totalNumOfComponents);
		out.println("Average Component Size:" + totalComponentSize
				/ totalNumOfComponents + " Classes");
		out.println("Average Semantic Correctness for all Components: "
				+ sumOfAllFFComponents / totalNumOfComponents);
		out.println("Average Specefity for all Components: "
				+ sumOfAllSpecComponents / totalNumOfComponents);
		out.println("Average Autonomy for all Components: "
				+ sumOfAllAutonomyComponents / totalNumOfComponents);
		out.println("Average Composability for all Components: "
				+ sumOfAllComposabilityComponents / totalNumOfComponents);
		out.println();
		out.println("Clusters analysis");
		out.println("Total Number Of Cluster: " + i);
		out.println("Average Number Of component in clusters: "
				+ sumOfAllComponent / i);
		out.println("Average Number Of Common classes in clusters: "
				+ sumOfAllCommonClasses / i);
		out.println("Average Semantic correctness for common: "
				+ sumOfFFofCommonClasses / i);
		out.println("Average Specefity for common: " + sumOfSpecofCommonClasses
				/ i);
		out.println("Average Autonomy for common: "
				+ sumOfAutonomyofCommonClasses / i);
		out.println("Average Composability for common: "
				+ sumOfComposabilityCommonClasses / i);

		out.println("Average Number Of Variable classes in clusters: "
				+ sumOfAllVarClasses / i);

	}

	public static void printDocuments(ArrayList<Component> docs) {
		for (int i = 0; i < docs.size(); i++) {
			System.err.println(docs.get(i).toString());
		}
	}
}
