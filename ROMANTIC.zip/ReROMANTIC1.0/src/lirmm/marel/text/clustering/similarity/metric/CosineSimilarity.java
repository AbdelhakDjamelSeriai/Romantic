package lirmm.marel.text.clustering.similarity.metric;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import lirmm.marel.text.clustering.algorithms.BinaryTree;
import lirmm.marel.text.clustering.algorithms.Node;
import lirmm.marel.text.clustering.dataset.Component;


public class CosineSimilarity {

	public static void calculateSimilarity(Component doc1, Component doc2){
		
	}
	
	/**
     * gets the similarity of the two strings using CosineSimilarity.
     *
     * @param string1
     * @param string2
     * @return a value between 0-1 of the similarity
     */
    public static float getSimilarity(ArrayList<Component> set1, ArrayList<Component> set2) {
    	if(set1.size() == 1 && set2.size() == 1){
//    		System.err.println("inside if");
    		return getSimilarityBetweenTwoStrings(set1.get(0).getTerms(),set2.get(0).getTerms()); 
    	}
    	
    	ArrayList<String> set1Tokens= new ArrayList<String>();
    	ArrayList<String> set2Tokens= new ArrayList<String>();
    	for (int i=0; i < set1.size();i++){
    		Component doc= set1.get(i);
    		set1Tokens.addAll(doc.getTerms());
    	}
    	for (int i=0; i < set2.size();i++){
    		Component doc= set2.get(i);
    		set2Tokens.addAll(doc.getTerms());
    	}
        final Set<String> allTokens = new HashSet<String>();
        allTokens.addAll(set1Tokens);
        final int termsInString1 = allTokens.size();
        final Set<String> secondStringTokens = new HashSet<String>();
        secondStringTokens.addAll(set2Tokens);
        final int termsInString2 = secondStringTokens.size();

        //now combine the sets
        allTokens.addAll(secondStringTokens);
        final int commonTerms = (termsInString1 + termsInString2) - allTokens.size();

        //return CosineSimilarity
        return (float) (commonTerms) / (float) (Math.pow((float) termsInString1, 0.5f) * Math.pow((float) termsInString2, 0.5f));
    }
	
    
    public static float getSimilarityBetweenSets(Set<Component> setOfDoc1, Set<Component> setOfDoc2) {
    	ArrayList<Component> set1 = new ArrayList<Component>(setOfDoc1);
    	ArrayList<Component> set2 = new ArrayList<Component>(setOfDoc2);
    	if(set1.size() == 1 && set2.size() == 1){
    		return getSimilarityBetweenTwoStrings(set1.get(0).getTerms(),set2.get(0).getTerms()); 
    	}
    	
    	ArrayList<String> set1Tokens= new ArrayList<String>();
    	ArrayList<String> set2Tokens= new ArrayList<String>();
    	for (int i=0; i < set1.size();i++){
    		Component doc= set1.get(i);
    		set1Tokens.addAll(doc.getTerms());
    	}
    	for (int i=0; i < set2.size();i++){
    		Component doc= set2.get(i);
    		set2Tokens.addAll(doc.getTerms());
    	}
        final Set<String> allTokens = new HashSet<String>();
        allTokens.addAll(set1Tokens);
        final int termsInString1 = allTokens.size();
        final Set<String> secondStringTokens = new HashSet<String>();
        secondStringTokens.addAll(set2Tokens);
        final int termsInString2 = secondStringTokens.size();

        //now combine the sets
        allTokens.addAll(secondStringTokens);
        final int commonTerms = (termsInString1 + termsInString2) - allTokens.size();

        //return CosineSimilarity
//        System.err.println("getSimilarityBetweenSets: "+(float) (commonTerms) / (float) (Math.pow((float) termsInString1, 0.5f) * Math.pow((float) termsInString2, 0.5f)));
        return (float) (commonTerms) / (float) (Math.pow((float) termsInString1, 0.5f) * Math.pow((float) termsInString2, 0.5f));
    }
    
    public static float getSimilarityNode(Node n) {
    	
    	Set<Component> setOfDoc1=null;
    	Set<Component> setOfDoc2= null;
    	if (n instanceof BinaryTree) {
    		setOfDoc1 = (((BinaryTree) n)
    				.getNode1().getComponents());
    		setOfDoc2 = (((BinaryTree) n)
    				.getNode2().getComponents());
    		return getSimilarityBetweenSets(setOfDoc1, setOfDoc2);
		}else{
			System.err.println("leaf node:");
			return getSimilarityOneSet(n.getComponents());
		}
    	
    	
    }
    
    
    public static float getSimilarityOneSet(Set<Component> setOfDoc) {
    	ArrayList<Component> docs = new ArrayList<Component>(setOfDoc);
    	float averageSimilarity= 0;
    	float sumOfSimilarity=0;    	
    	for (int i=0;i<docs.size();i++) {
			for (int j=i+1;j<docs.size();j++) {
				ArrayList<String> str1Tokens = docs.get(i).getTerms();
				ArrayList<String> str2Tokens= docs.get(j).getTerms();
				sumOfSimilarity+= getSimilarityBetweenTwoStrings(str1Tokens, str2Tokens);
			}
    	}
    	averageSimilarity = sumOfSimilarity/docs.size();
    	//return CosineSimilarity
        return (float) averageSimilarity;
    }
    
	 /**
     * gets the similarity of the two strings using CosineSimilarity.
     *
     * @param string1
     * @param string2
     * @return a value between 0-1 of the similarity
     */
    public static float getSimilarityBetweenTwoStrings(ArrayList<String> str1Tokens, ArrayList<String> str2Tokens) {
        final Set<String> allTokens = new HashSet<String>();
        allTokens.addAll(str1Tokens);
        final int termsInString1 = allTokens.size();
        final Set<String> secondStringTokens = new HashSet<String>();
        secondStringTokens.addAll(str2Tokens);
        final int termsInString2 = secondStringTokens.size();

        //now combine the sets
        allTokens.addAll(secondStringTokens);
        final int commonTerms = (termsInString1 + termsInString2) - allTokens.size();

        //return CosineSimilarity
        return (float) (commonTerms) / (float) (Math.pow((float) termsInString1, 0.5f) * Math.pow((float) termsInString2, 0.5f));
    }
}
