package lirmm.marel.ast.parser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import lirmm.marel.romantic.object.elements.Attribute;
import lirmm.marel.romantic.object.elements.Method;
import lirmm.marel.romantic.object.elements.OOProduct;
import lirmm.marel.romantic.object.elements.Class;
//import lirmm.marel.romantic.object.elements.Method;
//import lirmm.marel.romantic.object.elements.Attribute;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.TypeDeclaration;

//import romantic.metamodel.Attribute;
//import romantic.metamodel.Clazz;
//import romantic.metamodel.Method;
//import romantic.metamodel.OOSystem;

public class Util {
	public static String readFileAsString(String filePath)
		    throws java.io.IOException{
		        StringBuffer fileData = new StringBuffer(1000);
		        BufferedReader reader = new BufferedReader(new FileReader(filePath));
		        char[] buf = new char[1024];
		        int numRead=0;
		        while((numRead=reader.read(buf)) != -1){
		            String readData = String.valueOf(buf, 0, numRead);
		            fileData.append(readData);
		            buf = new char[1024];
		        }
		        reader.close();
		        return fileData.toString();
		    }
	
	public static void extractClass(String filePath,OOProduct oosystem) {
		
	}
		public static void parse(String filename, OOProduct oosystem) throws IOException {
		ASTParser parser = ASTParser.newParser(AST.JLS3);
		parser.setSource(Util.readFileAsString(""+filename).toCharArray());
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setEnvironment(null, new String[]{""}, null, true);
		parser.setUnitName(new File(filename).getName());
		parser.setResolveBindings(true);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		//Creation du systeme
		//OOSystem oosystem = new OOSystem();
		//Visite de toutes les classes du fichier
		TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
		cu.accept(typeDeclarationVisitor);
		//Pour chaque classe
		for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
//	]		System.out.println("Classe trouvée : " + typeDeclaration.getName().getIdentifier());
			Class clazz = oosystem.getClassByName(typeDeclaration.getName().getIdentifier());
			if (clazz==null) {
				clazz = new Class(typeDeclaration.getName().getIdentifier(), typeDeclaration.getName().getFullyQualifiedName());
				oosystem.add(clazz);
			};
			//visite de toutes les declaration de methodes
			MethodDeclarationVisitor methodDeclarationVisitor = new MethodDeclarationVisitor();
			typeDeclaration.accept(methodDeclarationVisitor);
			for (MethodDeclaration methodDeclaration : methodDeclarationVisitor.getMethods()) {
//				System.out.println("Method trouvée : " + methodDeclaration.getName().getIdentifier());
				Method method = clazz.getMethodByName(methodDeclaration.getName().getIdentifier());
				if (method==null) {
					method = new Method(methodDeclaration.getName().getIdentifier(),clazz);
					clazz.addMethod(method);
				}
				//Visite de toutes les invocations de methodes dans chaque declaration de method
				MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
				methodDeclaration.accept(methodInvocationVisitor);
				for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods()) {
					//Resoudre le binding pour voir si la classe appartient au systeme
					IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
					if (methodBinding != null && methodBinding.getDeclaringClass()!= null) {
						//la classe existe dans le classpath
						String calledClazzName = methodBinding.getDeclaringClass().getName();
//						System.out.println("Invocation de methode trouvée : " + calledClazzName + "."+methodInvocation.getName().getIdentifier());
						Class calledClazz = oosystem.getClassByName(calledClazzName);
						Method calledMethod;
						if (calledClazz==null) {
							calledClazz = new Class(calledClazzName, methodBinding.getDeclaringClass().getQualifiedName());
							oosystem.add(calledClazz);
							calledMethod = new Method(methodBinding.getName(),calledClazz);
							calledClazz.addMethod(calledMethod);
						} else {
							// la classe existe dans le systeme
							calledMethod = calledClazz.getMethodByName(methodBinding.getName());
							if (calledMethod==null) {
								calledMethod = new Method(methodBinding.getName(),calledClazz);
								calledClazz.addMethod(calledMethod);
							}
						}
//						System.out.println("Ajout de " + calledClazzName + "."+calledMethod.getName() + " au invocation de " + method.getName());
						method.addCalledMethod(calledMethod);
					}
				}
				
				//Visite de tous les acces aux attributs dans chaque declaration de méthode
				AttributeAccessVisitor attributeAccessVisitor = new AttributeAccessVisitor();
				methodDeclaration.accept(attributeAccessVisitor);
				for (SimpleName simpleName : attributeAccessVisitor.getFields()) {
					//Resoudre le binding pour voir si l'instruction est un access à une variable
					IVariableBinding variableBinding = (IVariableBinding)simpleName.resolveBinding();
					if (variableBinding != null) {
						//la classe existe dans le classpath
						//si getDeclaringClass retourne null alors c'est une variable local
						if (variableBinding.getDeclaringClass()!=null) {
							String calledClazzName = variableBinding.getDeclaringClass().getName();
//							System.out.println("Accés à attribut trouvée : " + calledClazzName + "."+variableBinding.getName());
							Class calledClazz = oosystem.getClassByName(calledClazzName);
							Attribute accessedAttribute;
							if (calledClazz==null) {
								calledClazz = new Class(calledClazzName, variableBinding.getDeclaringClass().getQualifiedName());
								oosystem.add(calledClazz);
								accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
							} else {
								// la classe existe dans le systeme
								accessedAttribute = calledClazz.getAttributeByName(variableBinding.getName());
								if (accessedAttribute==null) {
									accessedAttribute = new Attribute(variableBinding.getName(),calledClazz);
								calledClazz.addAttribute(accessedAttribute);
								}
							}
//							System.out.println("Ajout de " + calledClazzName + "."+accessedAttribute.getName() + " au acces de " + method.getName());
							method.addAccessedAttribute(accessedAttribute);
						}
					}
				}
				
			}
			
		}
	}
	
	
	
	
	public static void printSystem(OOProduct oosystem, PrintStream out) {
		out.println(oosystem.toString());
		
	}
	
	public static void printSystemOld(OOProduct oosystem, PrintStream out) {
		out.println("*******");
		out.println("Système");
		out.println("*******");
		out.println(oosystem.getClasses().size() + " classes");
		for (Class clazz : oosystem.getClasses()) {
			out.println(clazz.getFullName() + "{");
			for (Method method : clazz.getMethods()) {
				out.println("  " + method.getName() + "() {");
				for (Method calledMethod : method.getCalledMethods()) {
					out.println("    " + calledMethod.getClazz().getFullName()+"."+calledMethod.getName() + "();");
				}
				for (Attribute accessedAttribute : method.getAccessedAttributes()) {
					out.println("    " + accessedAttribute.getClazz().getFullName()+"."+accessedAttribute.getName()+";");
				}
				out.println("  " + "}\n");
			}
			
			for (Attribute attribute : clazz.getAttributes()) {
				out.println("  " + attribute.getName() + ";");
			}
			
			out.println("}\n");
			
		}
	}
	
	public static void removeNonFileClasses(OOProduct oosystem, Collection<File> listOfFiles) {
		Set<Class> classes = new TreeSet<Class>();
		for (Class clazz : oosystem.getClasses()) {
			if (isFileClass(clazz, listOfFiles)){
				classes.add(clazz);
			}
		}
		oosystem.getClasses().retainAll(classes);
	}
	
	private static boolean isFileClass(Class c, Collection<File> listOfFiles){
		for (File file : listOfFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
//			System.err.println("path:"+path);
			StringTokenizer t = new StringTokenizer(path, "/", false);
			String s[]= path.split("/");
			s[s.length-1]=s[s.length-1].substring(0, s[s.length-1].length()-5);
			if (c.getName().equals(s[s.length-1])){
//				System.err.println(c.getName() + " , true");
				return true;
			}
		}
//		System.err.println(c.getName() + " , false");
		return false;
	}
}
