/**
 * 
 */
package lirmm.marel.romantic.object.elements;

import java.util.Set;
import java.util.TreeSet;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class OOProduct {

	private Set<Class> classes = new TreeSet<Class>();

	/**
	 * @return all classes
	 */
	public Set<Class> getClasses() {
		return classes;
	}

	/**
	 * @param add a class c
	 * @return
	 */
	public boolean add(Class c) {
		return classes.add(c);
	}
	
	/**
	 * @param name of needed class
	 * @return class, null if not exist
	 */
	public Class getClassByName(String name) {
		for (Class c : classes) {
			if (c.getName().equals(name)) {
				return c;
			}
		}
		return null;
	}
	public String toString() {
		String str="";
		str+= "This product contains " +this.classes.size() + " classes.\n";
		str+="List Of Classes is:\n";
		int i=0;
		for (Class c:classes){
			
			str+= c.toString();
//			System.err.println(i++);
//			System.err.println(str);
		}
		return str;
	}
}
