/**
 * 
 */
package lirmm.marel.romantic.object.elements;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class Attribute extends OOElement implements Comparable<Attribute>{

	/**
	 * @param attribute name
	 * @param class owner
	 */
	public Attribute(String name, Class clazz) {
		super(name, clazz);		
	}

	public String toString() {
		String str="\t\tAtt Name: ";
		str+=getName();
		return str;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Attribute o) {
		// TODO Auto-generated method stub
		return getName().compareTo(o.getName());
	}
}
