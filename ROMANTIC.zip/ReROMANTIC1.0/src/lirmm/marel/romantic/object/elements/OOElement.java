/**
 * 
 */
package lirmm.marel.romantic.object.elements;

/**
 * @author Anas Shatnawi anasshatnawi@gmail.com
 */
public class OOElement {

	private String name;
	private Class classOwner;

	/**
	 * @param name
	 * @param clazz
	 */
	public OOElement(String name, Class classOwner) {
		super();
		this.name = name;
		this.classOwner = classOwner;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param set name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return class Owner
	 */
	public Class getClazz() {
		return classOwner;
	}

	/**
	 * @param set Class Owner
	 */
	public void setClass(Class clazz) {
		this.classOwner = clazz;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "Classe Owner: " + classOwner.getFullName() + " Name" + name;
	}

}
