/**
 * 
 */
package lirmm.marel.romantic.object.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class Method extends OOElement implements Comparable<Method>{

	/**
	 * holds a set of method that get called by this method
	 */
	private Set<Method> calledMethods = new TreeSet<Method>();
	/**
	 * holds a set of attributes that get accessed by this method
	 */
	private Set<Attribute> accessedAttributes = new TreeSet<Attribute>();
	
	/**
	 * @param name
	 * @param classOwner
	 */
	public Method(String name, Class classOwner) {
		super(name, classOwner);
	}

	/**
	 * @param method
	 */
	public void addCalledMethod(Method method) {
		calledMethods.add(method);
	}
	
	/**
	 * @param attribute
	 */
	public void addAccessedAttribute(Attribute a) {
		accessedAttributes.add(a);
	}

	/**
	 * @return method invocation
	 */
	public Set<Method> getCalledMethods() {
		return calledMethods;
	}

	/**
	 * @return accessed attributes
	 */
	public Set<Attribute> getAccessedAttributes() {
		return accessedAttributes;
	}
	
	public String toString() {
		String str="\t\tMethod Name: ";
		str+=getName();
		str+="\t\tCalled Methods: ";
		for (Method c : calledMethods){
			str+= "\t\t"+c.getName() + " form class "+c.getClazz().getFullName() +"\n";
		}
		str+="\t\tAccess Attributes: ";
		for (Attribute a : accessedAttributes){
			str+= "\t\t"+a.getName() + " form class "+a.getClazz().getFullName() +"\n";
		}
		return str;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Method o) {
		// TODO Auto-generated method stub
		return getName().compareTo(o.getName());
	}
}
