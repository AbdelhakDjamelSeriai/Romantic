/**
 * 
 */
package lirmm.marel.romantic.object.elements;

import java.util.Set;
import java.util.TreeSet;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class Class implements Comparable<Class> {
	/**
	 * the class name
	 */
	private String name;
	private String fullName;
	/**
	 * the set of methods membering in this class
	 */
	private Set<Method> methods = new TreeSet<Method>();
	/**
	 * the set of attributes membering in this class
	 */
	private Set<Attribute> attributes = new TreeSet<Attribute>();
	
	public Class(String name, String fullName) {
		this.name = name;
		this.fullName = fullName;
	}
	
	/**
	 * @return the class name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param set the class name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	public String getFullName() {
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	/**
	 * @return a set of member methods
	 */
	public Set<Method> getMethods() {
		return methods;
	}

	/**
	 * @return a set of member attributes
	 */
	public Set<Attribute> getAttributes() {
		return attributes;
	}

	/**
	 * @param add a method to the class
	 */
	public void addMethod(Method m) {
		methods.add(m);
		m.setClass(this);
	}

	/**
	 * @param add an attribute to the class
	 */
	public void addAttribute(Attribute a) {
//		System.err.println(this.name);
//		System.err.print(a.getName());
		attributes.add(a);
//		System.err.println(getAttributeByName(a.getName()));
		a.setClass(this);
	}
	
	/**
	 * @param name of quary method
	 * @return the method, null if not exist
	 */
	public Method getMethodByName(String name) {
		for (Method m : methods) {
			if (m.getName().equals(name)) {
				return m;
			}
		}
		return null;
	}
	
	/**
	 * @param name of quaery attribute
	 * @return needed attribute, null if not exist
	 */
	public Attribute getAttributeByName(String name2) {
		for (Attribute a : attributes) {
			if (a.getName().equals(name2)) {
				return a;
			}
		}
		return null;
	}
	
	public String toString() {
		String str="";
//		str+= "\tClass Name: ";
		str+= name+ " ";
//		str+= " ,  contains:\n";
//		str+="\t\tList of Attributes is ("+attributes.size()+") : \n";
////		System.err.println(attributes);
//		for (Attribute a:attributes){
//			str+= a.toString();
//		}
//		str+="\n\t\tList of Methods is("+methods.size()+") : \n";
//		for (Method m:methods){
//			str+= m.toString();
//		}
		return str;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Class o) {
		// TODO Auto-generated method stub
		return name.compareTo(o.name);
	}
}
