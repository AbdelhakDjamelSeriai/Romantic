package lirmm.marel.romantic.partitioning.clustering;

import java.util.Set;

import lirmm.marel.romantic.object.elements.Class;


public abstract class Node implements Comparable<Node> {
	public int id;
	public abstract Set<Class> getClasses();
	
	public static int currentID=0;
	public static int generateID(){
//		System.err.println("current id : "+currentID);
		return currentID++;
	}
}
