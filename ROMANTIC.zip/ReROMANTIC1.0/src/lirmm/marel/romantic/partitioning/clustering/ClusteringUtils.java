package lirmm.marel.romantic.partitioning.clustering;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import lirmm.marel.romantic.documentation.ComponentNaming;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.romantic.quality.QualityFunction;
import lirmm.marel.romantic.util.Constant;

/**
 * @author Anas Shatnawi anasshatnawi@gmail.com
 */
public class ClusteringUtils {
	public static BinaryTree clustering(Set<Class> classes) {
		System.err
				.println("\t1building binary tree, it may take long time depending on your data size...");
		Set<Node> noeuds = new TreeSet<Node>();
		int taille = classes.size();
		double max;
		BinaryTree b = null;
		for (Class c : classes) {
			noeuds.add(new Leaf(c));
		}
		System.err.println("\t\tleaf nodes are added");
		System.err.println("\t\tbinary tree agromalitive aggregation starting");
		int nombre = 1;
		do {
			Node[] noeudsArray = noeuds.toArray(new Node[0]);
			
			int total = noeuds.size() * (noeuds.size() - 1) / 2;
			Node n1 = noeudsArray[0];
			Node n2 = noeudsArray[1];
			Set<Class> cluster = new TreeSet<Class>();
			cluster.addAll(n1.getClasses());
			cluster.addAll(n2.getClasses());
			max = QualityFunction.QualityFun(cluster);
			nombre++;
			double value;
			for (int i = 0; i < noeudsArray.length; i++) {
				for (int j = i + 1; j < noeudsArray.length; j++) {
					Set<Class> cluster1 = new TreeSet<Class>();
					cluster1.addAll(noeudsArray[i].getClasses());
					cluster1.addAll(noeudsArray[j].getClasses());
					value = QualityFunction.QualityFun(cluster1);
//					nombre++;
					if (value >= max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
					}
				}
			}
//			System.err.println("level : "+nombre);
			b = new BinaryTree();
			b.setNode1(n1);
			b.setNode2(n2);
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
		} while (b.numberOfLeaves() != taille);
		System.err.println("\t\tbinary tree was built");
		return b;
	}

	//
	public static Set<Set<Class>> parcoursDendrogramme(BinaryTree dendrogramme,
			double t) {
		System.err
				.println("\textracting the best cluster form the binaru tree...");
		Set<Set<Class>> result = new HashSet<Set<Class>>();
		Stack<Node> pile = new Stack<Node>();
		pile.push(dendrogramme);
		while (!pile.isEmpty()) {
			Node pere = pile.pop();
			Set<Class> pereCluster = pere.getClasses();
			if (pere instanceof BinaryTree) {
				Set<Class> fils1Cluster = (((BinaryTree) pere).getNode1()
						.getClasses());
				Set<Class> fils2Cluster = (((BinaryTree) pere).getNode2()
						.getClasses());
				double valuePere = QualityFunction.QualityFun(pereCluster);
				double valueFils1 = QualityFunction.QualityFun(fils1Cluster);
				double valueFils2 = QualityFunction.QualityFun(fils2Cluster);
				if (valuePere > (valueFils1 + valueFils2) * t) {
//					Constant.AllCompoSize+=fils1Cluster.size();
//					Constant.AllCompoSize+=fils1Cluster.size();
					result.add(pereCluster);
				} else {
					pile.add(((BinaryTree) pere).getNode1());
					pile.add(((BinaryTree) pere).getNode2());
				}
			} else {
//				Constant.AllCompoSize+= 1;
				result.add(pereCluster);
			}
		}
		return result;

	}

	public static void parcoursDendro(BinaryTree dendro, String s) {
		System.out.println(s + "pere" + dendro.getClasses());
		if (dendro.getNode1() instanceof BinaryTree)
			parcoursDendro((BinaryTree) dendro.getNode1(), s + "  ");
		else
			System.out.println(s + "  fils1"
					+ ((Leaf) dendro.getNode1()).getClasses());
		if (dendro.getNode2() instanceof BinaryTree)
			parcoursDendro((BinaryTree) dendro.getNode2(), s + "  ");
		else
			System.out.println(s + "  fils2"
					+ ((Leaf) dendro.getNode2()).getClasses());
	}

	
	public static void printClusters(Set<Set<Class>> clusters, PrintStream out) {
		int i = 1;
		// Set<Component> components = new HashSet<Component>();
		for (Set<Class> cluster : clusters) {
			out.println("");
			out.println("Cluster " + i + "(" + cluster.size() + " classes).");
			out.println("Cluster Name : "
					+ ComponentNaming.componentName(cluster));
			for (Class clazz : cluster) {
				if(clazz.getName().equals(clazz.getFullName()))//ignor java class existing on API
				out.println("" + clazz.getFullName());
			}
			i++;
			// components.add(new
			// Component(ComponentNaming.componentName(cluster), cluster));
		}
		// for(Component c:components){
		// System.err.println(c.toString());
		// }
	}
	
	
	public static void printSimpleFormatClusters(Set<Set<Class>> clusters, PrintStream out) {
		int i = 1;
		// Set<Component> components = new HashSet<Component>();
		for (Set<Class> cluster : clusters) {
			out.println("c1." + cluster.size() +"."+ ComponentNaming.componentName(cluster)+";");
			for (Class clazz : cluster) {
				if(clazz.getName().equals(clazz.getFullName()))//ignor java class existing on API
				out.print("," + clazz.getFullName());
				
			}
			out.println("*");
			out.println("");
			i++;
			// components.add(new
			// Component(ComponentNaming.componentName(cluster), cluster));
		}
		// for(Component c:components){
		// System.err.println(c.toString());
		// }
	}
}
