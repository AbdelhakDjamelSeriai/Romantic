/**
 * 
 */
package lirmm.marel.romantic.quality;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import lirmm.marel.romantic.object.elements.Attribute;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.romantic.object.elements.Method;

/**
 * @author Anas Shatnawi anasshatnawi@gmail.com
 */
public class QualityFunction {

	public static double QualityFun(Set<Class> clazzes) {
		if (clazzes.size()==0){
			return 0;
		}
		double quality = 0;
		int lambda1 = 3;
		int lambda2 = 3;
		int lambda3 = 1;
//		System.err.println("Class [" + clazzes.toString() + "]");
		double coupling = coupling(clazzes);
//		 c = (lambda1 *  coupling + lambda3 * (1-coupling))
//					/ (lambda1 +  + lambda3);
		double tccClasses = tccClasses(clazzes) ;
//		System.err.println("tccClasses = " + tccClasses);
		double specificity = tccClasses / 2.0 + coupling / 2.0 ;
//		System.err.println("specificity = " + specificity);
		double autonomy = 1 - coupling;
//		System.err.println("autonomy = " + autonomy);
		double composability =tccClasses;
//		System.err.println("composability = " + composability);
		quality = (lambda1 * specificity + lambda2
				* composability+ lambda3 * autonomy)
				/ (lambda1 + lambda2 + lambda3);
//		System.err.println("quality = " + quality);
//		System.err.println("----------------------------------------------");
		return quality;
	}

	public static double specFun(Set<Class> clazzes) {
		double coupling = coupling(clazzes);
//		 c = (lambda1 *  coupling + lambda3 * (1-coupling))
//					/ (lambda1 +  + lambda3);
		double tccClasses = tccClasses(clazzes) ;
		double specificity = tccClasses / 2.0 + coupling / 2.0 ;
		return specificity;
	}

	public static double composFun(Set<Class> clazzes) {
		return tccClasses(clazzes);
	}

	public static double autFun(Set<Class> clazzes) {
		return 1 - coupling(clazzes);
	}

	private static boolean isDirectlyConnected(Method m1, Method m2) {
		Set<Attribute> intersection = new HashSet<Attribute>(
				m1.getAccessedAttributes());
		intersection.retainAll(m2.getAccessedAttributes());
		if (!intersection.isEmpty()) {
			return true;
		}
		Set<Method> intersection2 = new HashSet<Method>(m1.getCalledMethods());
		intersection2.retainAll(m2.getCalledMethods());
		if (!intersection2.isEmpty()) {
			return true;
		}
		return false;
	}
	
	public static double tccMethods(Set<Method> methods) {
		double ndc = 0;
		Method[] methodsArray = methods.toArray(new Method[0]);
		for (int i = 0; i < methodsArray.length; i++){
			for (int j = i + 1; j < methodsArray.length; j++){
				if (isDirectlyConnected(methodsArray[i], methodsArray[j])){
					ndc++;
				}
			}
		}
		double np = methods.size() * (methods.size() - 1) / 2;
		if (np == 0)
			return 0.5;
//		System.err.println(np+"........................");
		double result = ndc / np + 0.5; // sumation on i 
		if (result > 1.0)
			return 1.0;
		else
			return result;
	}
	
	public static double tccClasses(Set<Class> classes) {
		Set<Method> methods = new TreeSet<Method>();
		for (Class clazz : classes) {
			methods.addAll(clazz.getMethods());
		}
		return tccMethods(methods);
	}
	
	public static double coupling(Set<Class> clazzes) {
		double numberOfInsideCalledClazzes = 0;
		Set<Class> calledClazzes = new HashSet<Class>();
		for (Class c : clazzes) {
			for (Method m : c.getMethods()) {
				for (Method calledM : m.getCalledMethods()) {
					calledClazzes.add(calledM.getClazz());
				}
				for (Attribute accessedA : m.getAccessedAttributes()) {
					calledClazzes.add(accessedA.getClazz());
				}
			}
		}
		
		if (calledClazzes.size() == 0) {
			return 1;
		}
		for (Class calledClazz : calledClazzes) {
			if (clazzes.contains(calledClazz)) {
				numberOfInsideCalledClazzes++;
			}
		}

		return numberOfInsideCalledClazzes / clazzes.size();
	}
	

}
