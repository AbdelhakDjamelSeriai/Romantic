package lirmm.marel.romantic.documentation;

import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.romantic.partitioning.clustering.BinaryTree;
import lirmm.marel.romantic.partitioning.clustering.Leaf;
import lirmm.marel.romantic.partitioning.clustering.Node;
import lirmm.marel.romantic.quality.QualityFunction;
import lirmm.marel.text.clustering.dataset.Component;

public class DocumentationOfComponents {
	Component component;
	Vector functionality;

	public DocumentationOfComponents(Component component) {
		this.component = component;
		functionality = new Vector();
	}

	public void extractFunctionalities() {
		if (component.getClasses().size() == 1){
			return;
		}
		BinaryTree binaryTree = clustering(component.getClasses());
		Set<Set<Class>> potentialFunctions = parcoursDendrogramme(binaryTree,0.5);
//		Set<Set<Clazz>> potentialFunctions = getAllBestComponentConstraint(component
//				.getClasses());
		for (Set<Class> group : potentialFunctions) {
			Component subComponent = new Component(0,
					ComponentNaming.componentName(group), group);
			functionality.add(subComponent);
		}
//		BinaryTree binaryTree = clustering(component.getClasses());
//		Set<Set<Clazz>> clusters = parcoursDendrogramme(binaryTree,0.5);
	}

	public Vector getFunctionality() {
		return functionality;
	}
	
	public String toString() {
		String str="contains "+functionality.size()+" functionality(s). Which are:";
		for (int i = 0 ; i< functionality.size(); i++){
			Component com= (Component) functionality.elementAt(i);
			str += com.toString();
			str +="\n";
		}
		return str;		
	}
	
	public static BinaryTree clustering(Set<Class> classes) {
		double progress = 1;
//		System.err.println("BT progress: "+(progress/100));
		Set<Node> noeuds = new HashSet<Node>();
		int taille = classes.size();
		double max;
		BinaryTree b = null;
		for (Class c : classes) {
			noeuds.add(new Leaf(c));
		}
		progress=6;
//		System.err.println("BT progress: "+(progress/100));
		for (Node n : noeuds) {
			Set<Class> cluster = new HashSet<Class>();
			cluster.addAll(n.getClasses());
			max = QualityFunction.specFun(cluster);
//			System.out.println(cluster + " " + max);
		}
		progress = 15;
//		System.err.println("BT progress: "+(progress/100));
		do {
			Node[] noeudsArray = noeuds.toArray(new Node[0]);
			int nombre = 1;
			int total = noeuds.size() * (noeuds.size() - 1) / 2;
			Node n1 = noeudsArray[0];
			Node n2 = noeudsArray[1];
			Set<Class> cluster = new HashSet<Class>();
			cluster.addAll(n1.getClasses());
			cluster.addAll(n2.getClasses());
			max =  QualityFunction.specFun(cluster);
			//System.out.println(cluster + " " + max);
//			System.out.println( nombre + "/" + total);
			nombre ++;
			progress = 20;
//			System.err.println("BT progress: "+(progress/100));
			for (int i=2;i<noeudsArray.length;i++) {
				Set<Class> cluster1 = new HashSet<Class>();
				cluster1.addAll(noeudsArray[0].getClasses());
				cluster1.addAll(noeudsArray[i].getClasses());

				double value =  QualityFunction.specFun(cluster1);
				//System.out.println(cluster1 + " " + value);
//				System.out.println(nombre + "/" + total);
				nombre ++;
				if (value>max) {
					n1 = noeudsArray[0];
					n2 = noeudsArray[i];
					max = value;
				}
			}
			progress = 40;
//			System.err.println("BT progress: "+(progress/100));
			//System.out.println(max);
			for (int i=0;i<noeudsArray.length;i++) {
				for (int j=i+1;j<noeudsArray.length;j++) {
					Set<Class> cluster1 = new HashSet<Class>();
					cluster1.addAll(noeudsArray[i].getClasses());
					cluster1.addAll(noeudsArray[j].getClasses());

					double value =  QualityFunction.specFun(cluster1);
					//System.out.println(cluster1 + " " + value);
//					System.out.println(nombre + "/" + total);
					nombre ++;
					if (value>=max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
					}
				}
 			}
			progress = 70;
//			System.err.println("BT progress: "+(progress/100));
			b = new BinaryTree();
			b.setNode1(n1);
			b.setNode2(n2);
//			System.out.println(b.numberOfLeaves());
//			System.out.println(b.getClasses());
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
			
		} while (b.numberOfLeaves()!=taille);
		progress = 100;
//		System.err.println("BT progress: "+(progress/100));
		return b;
	}
	public static Set<Set<Class>> parcoursDendrogramme(BinaryTree dendrogramme, double t) {
		Set<Set<Class>> result = new HashSet<Set<Class>>();
		Stack<Node> pile = new Stack<Node>();
		pile.push(dendrogramme);
		while (!pile.isEmpty()) {
			Node pere = pile.pop();
			Set<Class> pereCluster = pere.getClasses();
			if (pere instanceof BinaryTree) {
				Set<Class> fils1Cluster = (((BinaryTree) pere).getNode1().getClasses());
				Set<Class> fils2Cluster = (((BinaryTree) pere).getNode2().getClasses());
				double valuePere =  QualityFunction.specFun(pereCluster);				
				double valueFils1 =  QualityFunction.specFun(fils1Cluster);
				if (fils1Cluster.size() ==1){
					valueFils1=0;
				}
				double valueFils2 =  QualityFunction.specFun(fils2Cluster);
				if (fils2Cluster.size() ==1){
					valueFils2=0;
				}
				if (valuePere > (valueFils1 + valueFils2)*t)
						 {
					result.add(pereCluster);					
				} else {
					pile.add(((BinaryTree) pere).getNode1());
					pile.add(((BinaryTree) pere).getNode2());
				}					
			} else {
				result.add(pereCluster);
			}
		}
		return result;
			
	}
	public static Set<Set<Class>> getAllBestComponentConstraint(
			Set<Class> classes) {
		Set<Class> constraint = new HashSet<Class>();
		Set<Set<Class>> finalResult = new HashSet<Set<Class>>();
		for (Class c : classes) {
			constraint = new HashSet<Class>();
			constraint.add(c);
			Set<Class> tempSet = new HashSet<Class>();
			tempSet.addAll(classes);
			// System.err.println("next constraint:"+ c);
			Set<Class> bestResult = new HashSet<Class>();
			bestResult = getBestComponentConstraint(tempSet, constraint);
			// if (Metrics.f(bestResult) >=
			// AllCandedateCompIdMain.thresholdofFF) {
			// System.err.println(finalResult.add(bestResult));
			// System.err.println(bestResult);
			finalResult.add(bestResult);
			// AllCandedateCompIdMain.AllCompoSize =
			// AllCandedateCompIdMain.AllCompoSize + bestResult.size();
			// }

		}
		// Clazz[] tempClasses = classes.toArray(new Clazz[0]);
		return finalResult;
	}

	public static Set<Class> getBestComponentConstraint(Set<Class> classes,
			Set<Class> constraint) {
		classes.removeAll(constraint);
		Set<Class> addResult = new HashSet<Class>();
		Set<Class> bestResult = new HashSet<Class>();
		Set<Set<Class>> finalResult = new HashSet<Set<Class>>();
		addResult.addAll(constraint);
		bestResult.addAll(constraint);
		// System.err.println(addResult.toString());
		double maxFF = -1;
		Class nearestClass = null;
		int count = 0;
//		System.err.println(addResult);
//		System.err.println( QualityFunction.QualityFun(addResult));
		while (!classes.isEmpty()) {
			maxFF = -1;
			nearestClass = null;
			int i = 0;
			for (Class c : classes) {
				// System.err.println();
				Set<Class> tempCluster = new HashSet<Class>();
				tempCluster.addAll(addResult);
				tempCluster.add(c);
				// System.err.println("inside for: i="+i++);

				double fitness =  QualityFunction.specFun(tempCluster);
				if (fitness >= maxFF) {
					maxFF = fitness;
					nearestClass = c;
				}
				i++;
				// if (i >= 300){
				// break;
				// }
				// System.err.println("inside for, after if: i="+i++);
			}
			addResult.add(nearestClass);

//			 System.err.println(addResult);
//			 System.err.println(Metrics.f(addResult));

			if (maxFF >  QualityFunction.specFun(bestResult)) {
				bestResult = new HashSet<Class>();
				bestResult.addAll(addResult);
			}
			classes.remove(nearestClass);
			count++;
			// if (count >= 50){
			// break;
			// }
			// System.err.println("classes size : "+classes.size());
		}
		// System.err.println(bestResult.size());
		return bestResult;
	}
}
