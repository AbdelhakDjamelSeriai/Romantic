package lirmm.marel.romantic.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.io.FileUtils;


import lirmm.marel.ast.parser.Util;
import lirmm.marel.romantic.documentation.ComponentNaming;
import lirmm.marel.romantic.object.elements.OOProduct;
import lirmm.marel.romantic.partitioning.clustering.BinaryTree;
import lirmm.marel.romantic.partitioning.clustering.ClusteringUtils;
import lirmm.marel.romantic.util.Constant;
import lirmm.marel.romantic.object.elements.Class;
import lirmm.marel.text.clustering.dataset.Component;
import lirmm.marel.text.clustering.manager.ComponentClusterManager;



/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 * 
 * this class represents the main class that is used to manage the process of ROMANTIC extraction
 */
public class Main {
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		System.err.println("Hello, I'm the new ROMANTIC (:\n");
		System.err.println("Please wait, Soure code Reading...");
		Set<Component> components = new HashSet<Component>();
		int numOfComp = 0;
		double totalVariantSize = 0;
		for (int i=0; i< Constant.products.length;i++){
			Constant.products[i] = new OOProduct();
			Collection<File> listOfFiles = FileUtils.listFiles(new File("inputCode/p0"+(i+1)), new String[] {"java"}, true);
			for (File file : listOfFiles) {
				String path = new File("projet").toURI().relativize(file.toURI()).getPath();
				Util.parse(path, Constant.products[i]);
			}
			Util.removeNonFileClasses(Constant.products[i], listOfFiles);

			Util.printSystem(Constant.products[i], new PrintStream(new FileOutputStream("outputResults/system"+ (i+1)+".txt")));
			System.err.println("Source code reading is done, and printed in system.txt");
			System.err.println("\nPlease wait, starting component extraction...");
			//paritioning
			BinaryTree binaryTree = ClusteringUtils.clustering(Constant.products[i].getClasses());
			Set<Set<Class>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
			ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("outputResults/clusters"+(i+1)+".txt")));
			ClusteringUtils.printSimpleFormatClusters(clusters, new PrintStream(new FileOutputStream("outputResults/Simple Cluster"+(i+1)+".txt")));
			System.err.println("Components are extracted, and printed in cluster.txt, where ");
			System.err.println("Number of classes in the product : " + Constant.products[i].getClasses().size());
			System.err.println("Number of components : " + clusters.size());
			components.addAll(getComponent(clusters,i));
			totalVariantSize += Constant.products[i].getClasses().size();
	}
		numOfComp +=components.size();
		
		Constant.averageNumberOfCompo = ((double) numOfComp) / Constant.noOfPro;
		Constant.averageVariantSize = totalVariantSize / Constant.noOfPro;
		Constant.averageCompoSize = ((double) Constant.AllCompoSize) / numOfComp;
		System.err.println("\nPlease wait, starting component clustering...");
		ComponentClusterManager.startComponentClustering(components);
		// output
		System.err.println("finish");
	}

	
	public static Set<Component> getComponent(Set<Set<Class>> clusters, int productID) {
		int i = 1;
		Set<Component> components = new HashSet<Component>();
		for (Set<Class> cluster: clusters) {
			i++;
			components.add(new Component(productID, ComponentNaming
					.componentName(cluster), cluster));
		}
		return components;
	}
}
