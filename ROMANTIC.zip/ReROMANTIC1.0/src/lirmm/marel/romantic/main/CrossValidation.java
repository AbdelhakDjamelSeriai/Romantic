package lirmm.marel.romantic.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import lirmm.marel.ast.parser.Util;
import lirmm.marel.romantic.documentation.ComponentNaming;
import lirmm.marel.romantic.object.elements.OOProduct;
import lirmm.marel.romantic.partitioning.clustering.BinaryTree;
import lirmm.marel.romantic.partitioning.clustering.ClusteringUtils;
import lirmm.marel.romantic.util.Constant;
import lirmm.marel.text.clustering.dataset.Component;
import lirmm.marel.text.clustering.manager.ComponentClusterManager;
import lirmm.marel.romantic.object.elements.Class;




import org.apache.commons.io.FileUtils;


public class CrossValidation {
	public static Vector reusableComponents = new Vector<Component>();
	public static Set<Component> components = new HashSet<Component>();
	public static Set<Component> componentsForValidation = new HashSet<Component>();

	public static int startTrain = 4, endTrain = 7;
	public static int startTest = 0, endTest = 7;

	public static void main(String[] args) throws IOException {
		double totalVariantSize = 0;
		double NumOfcomponetVariant = 0;

		int numOfComp = 0;

		for (int i = 0; i < Constant.products.length; i++) {
			Constant.products[i] = new OOProduct();
			Collection<File> listOfFiles = FileUtils.listFiles(new File(
					"projet/p0" + (i + 1)), new String[] { "java" }, true);
			for (File file : listOfFiles) {
				String path = new File("projet").toURI()
						.relativize(file.toURI()).getPath();
				Util.parse(path, Constant.products[i]);
			}
			Util.printSystem(Constant.products[i], new PrintStream(new FileOutputStream(
					"AllCandidateSystem" + (i + 1) + ".txt")));

		}
		for (int i = startTest; i <= endTest; i++) {
//			Set<Set<Clazz>> allCandidates = AllCandiClusteringUtils
//					.getAllBestComponentConstraint(products[i].getClazzes());
//			componentsForValidation.addAll(getComponent(allCandidates, i));
			BinaryTree binaryTree = ClusteringUtils.clustering(Constant.products[i].getClasses());
			Set<Set<Class>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
			componentsForValidation = getComponent(clusters, i);
			
		}
		for (int i = startTrain; i <= endTrain; i++) {
//			if (i == startTest || i == endTest) {
//				Set<Set<Clazz>> allCandidates = AllCandiClusteringUtils
//						.getAllBestComponentConstraint(products[i].getClazzes());
//				componentsForValidation.addAll(getComponent(allCandidates, i));
//
//				continue;
//			}
			BinaryTree binaryTree = ClusteringUtils.clustering(Constant.products[0].getClasses());
			Set<Set<Class>> allCandidates = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
			components.addAll(getComponent(allCandidates, i));
			// for (Component component: components){
			// System.err.println("Decumentation of this component"+component.toString());
			// DocumentationOfComponents documentation = new
			// DocumentationOfComponents(component);
			// documentation.extractFunctionalities();
			// System.err.println(documentation.toString());
			// }

			// System.err.println(i+"..................................................................");
			ClusteringUtils.printClusters(allCandidates, new PrintStream(
					new FileOutputStream("AllCandidateClusters" + (i + 1)
							+ ".txt")));
			System.out.println("Nombre de classes : "
					+ Constant.products[i].getClasses().size());
			totalVariantSize += Constant.products[i].getClasses().size();
			// Nombre de clusters
			System.out.println("Nombre de clusters : " + allCandidates.size());
			numOfComp += allCandidates.size();
			// components.addAll(getComponent(allCandidates,i));

		}
		Constant.averageNumberOfCompo = ((double) numOfComp) / Constant.noOfPro;
		Constant.averageVariantSize = totalVariantSize / Constant.noOfPro;
		Constant.averageCompoSize = ((double) Constant.AllCompoSize) / numOfComp;
		System.err.println("average size of variants:" + Constant.averageVariantSize);

		ComponentClusterManager.startComponentClustering(components);
		System.err.println("productID:" + Constant.products[0].getClasses().size());
		System.err.println("total Number of component: " + numOfComp + "    "
				+ components.size());
		System.err.println("number of variants:"
				+ Constant.noOfPro);
		System.err.println("average size of variants:"
				+ Constant.averageVariantSize + " classes");
		System.err.println("average num of components in variants:"
				+ Constant.averageNumberOfCompo + " components");
		System.err.println("average  components size:"
				+ Constant.averageCompoSize + " classes");
		findCrossValidity();
		System.err.println("finish");
	}

	public static void findCrossValidityOld() {
		double avgOurCmpntReus = 0;
		double avgOldCmpntReus = 0;
		double minOurCmpntReus = 1;
		double minOldCmpntReus = 1;
		double maxOurCmpntReus = 0;
		double maxOldCmpntReus = 0;
		for (int i = 0; i < reusableComponents.size(); i++) {
			Component com = (Component) reusableComponents.elementAt(i);
			double reusability = getNumberOfProductBelongIn(com)
					/ Constant.noOfPro;
			avgOurCmpntReus += reusability;
			if (reusability > maxOurCmpntReus) {
				maxOurCmpntReus = reusability;
			}
			if (reusability < minOurCmpntReus) {
				minOurCmpntReus = reusability;
			}
		}
		for (Component comp : components) {
			double reusability = getNumberOfProductBelongIn(comp)
					/ Constant.noOfPro;
			avgOldCmpntReus += reusability;
			if (reusability > maxOldCmpntReus) {
				maxOldCmpntReus = reusability;
			}
			if (reusability < minOldCmpntReus) {
				minOldCmpntReus = reusability;
			}
		}
	}

	public static void findCrossValidity() {
		double avgOurCmpntReus = 0;
		double avgOldCmpntReus = 0;
		double minOurCmpntReus = 10;
		double minOldCmpntReus = 10;
		double maxOurCmpntReus = 0;
		double maxOldCmpntReus = 0;
		for (int i = 0; i < reusableComponents.size(); i++) {
			Component com = (Component) reusableComponents.elementAt(i);
			double reusability = getNumberOfCoveredComponents(com)
					/ components.size();
			avgOurCmpntReus += reusability;
			if (reusability > maxOurCmpntReus) {
				maxOurCmpntReus = reusability;
			}
			if (reusability < minOurCmpntReus) {
				minOurCmpntReus = reusability;
			}
		}
		for (Component comp : components) {
			double reusability = getNumberOfCoveredComponents(comp)
					/ components.size();
			avgOldCmpntReus += reusability;
			if (reusability > maxOldCmpntReus) {
				maxOldCmpntReus = reusability;
			}
			if (reusability < minOldCmpntReus) {
				minOldCmpntReus = reusability;
			}
		}
		System.err.println("componentsForValidation" + componentsForValidation.size());
		avgOurCmpntReus = avgOurCmpntReus / reusableComponents.size();
		avgOldCmpntReus = avgOldCmpntReus / components.size();
		System.err.println("Reusable components reusability: ");
		System.err.println("avg: " + avgOurCmpntReus);
		System.err.println("min: " + minOurCmpntReus);
		System.err.println("max: " + maxOurCmpntReus);
		System.err.println("num of Components: " + reusableComponents.size());
		System.err.println("traditional components reusability: ");
		System.err.println("avg: " + avgOldCmpntReus+ " : "+avgOldCmpntReus / components.size());
		System.err.println("min: " + minOldCmpntReus);
		System.err.println("max: " + maxOldCmpntReus);
		System.err.println("num of Components: " + components.size());
	}

	public static double getNumberOfCoveredComponents(Component component) {
		double count = 0;
		for (Component comp : componentsForValidation) {
			if (component.getClasses().containsAll(comp.getClasses())) {
				count++;
			}

		}
		return count;
	}

	public static double getNumberOfProductBelongIn(Component compo) {
		double count = 0;
		for (int i = startTest; i <= endTest; i++) {
			// if (i==startTrain && i==endTrain){
			// continue;
			// }
			if (Constant.products[i].getClasses().containsAll(compo.getClasses())) {
				count++;
			}
		}
		return count;
	}

	public static void countComponents() {
		int p;
	}

	public static Set<Component> getComponent(Set<Set<Class>> clusters,
			int productID) {
		int i = 1;
		Set<Component> components = new HashSet<Component>();
		for (Set<Class> cluster : clusters) {
			i++;
			components.add(new Component(productID, ComponentNaming
					.componentName(cluster), cluster));
		}
		return components;
	}
}
