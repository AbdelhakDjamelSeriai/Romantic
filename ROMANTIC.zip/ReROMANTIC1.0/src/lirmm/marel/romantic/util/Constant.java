/**
 * 
 */
package lirmm.marel.romantic.util;

import lirmm.marel.romantic.object.elements.OOProduct;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class Constant {

	public static final int noOfPro = 1;
	public static OOProduct products[]= new OOProduct[noOfPro];
	public static double thresholdofFF = 0.85;
	public static double averageVariantSize = 0;
	public static double averageNumberOfCompo = 0;
	public static double averageCompoSize = 0;
	public static long AllCompoSize = 0;
	
}
